#!/usr/bin/env bash
set -euo pipefail

# Shared path defaults for LISA-IAD training/evaluation scripts.
#
# Usage:
# - Option 1 (recommended): edit DATA_ROOT once to point to your local data/checkpoint folder.
# - Option 2: export DATA_ROOT / MODEL_PATH / SAM_CKPT / MVTEC_ROOT / VISA_ROOT / DTD_ROOT before running.
#
# Expected layout under DATA_ROOT:
#   DATA_ROOT/
#     Qwen/Qwen3-VL-4B-Instruct/
#     sam_vit_h_4b8939.pth
#     MVTec-AD/
#     VisA/
#     dtd/images/
#
# Note: This file is sourced by scripts that define ROOT_DIR (LISA-IAD repo root).
: "${ROOT_DIR:?ROOT_DIR must be set by the caller script.}"

DATA_ROOT="${DATA_ROOT:-${ROOT_DIR}/..}"

MODEL_PATH="${MODEL_PATH:-${DATA_ROOT}/Qwen/Qwen3-VL-4B-Instruct}"
SAM_CKPT="${SAM_CKPT:-${DATA_ROOT}/sam_vit_h_4b8939.pth}"

MVTEC_ROOT="${MVTEC_ROOT:-${DATA_ROOT}/MVTec-AD}"
VISA_ROOT="${VISA_ROOT:-${DATA_ROOT}/VisA}"
DTD_ROOT="${DTD_ROOT:-${DATA_ROOT}/dtd/images}"
