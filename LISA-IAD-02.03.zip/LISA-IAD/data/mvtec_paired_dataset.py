import cv2
import numpy as np
import torch
from PIL import Image

from .mvtec_prompts import (
    sample_assistant_defect,
    sample_assistant_mask_only,
    sample_assistant_normal,
    sample_user_prompt,
)
from .mvtec_dataset import MVtecIADDataset


class MVtecIADPairedDataset(MVtecIADDataset):
    """Paired training dataset (normal + synthetic) aligned with AnomalyGPT collate behavior."""

    def __init__(self, *args, **kwargs):
        split = kwargs.get("split", "train")
        if split != "train":
            raise ValueError("MVtecIADPairedDataset only supports split='train'.")
        super().__init__(*args, **kwargs)

    def __getitem__(self, idx: int):
        base = self.samples[idx]
        image_path = base["image_path"]
        class_name = base["class_name"]
        class_desc = self._get_class_desc(class_name)
        user_text = sample_user_prompt(self.rng, class_desc)

        image_bgr = cv2.imread(image_path)
        if image_bgr is None:
            raise ValueError(f"Failed to read image: {image_path}")
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

        # Normal sample
        image_pil = Image.fromarray(image_rgb)
        image_sam, resize, original_size = self._preprocess_sam(image_rgb)
        normal_gt_mask = torch.zeros((1, original_size[0], original_size[1]), dtype=torch.float32)
        if self.return_assistant:
            normal_assistant = (
                sample_assistant_mask_only(self.rng)
                if getattr(self, "assistant_mask_only", False)
                else sample_assistant_normal(self.rng, class_desc=class_desc)
            )
        else:
            normal_assistant = None
        normal_messages = self._build_messages_from_text(
            image_pil,
            user_text,
            assistant_text=normal_assistant,
        )
        normal_sample = {
            "image_path": image_path,
            "class_name": class_name,
            "defect_type": "good",
            "messages": normal_messages,
            "image_qwen": image_pil,
            "image_sam": image_sam,
            "sam_resize": resize,
            "sam_original_size": original_size,
            "gt_mask": normal_gt_mask,
            "has_mask": False,
            "synthetic": False,
        }

        # Synthetic sample
        patch_src = self.samples[self.prev_idx]["image_path"]
        patch_bgr = cv2.imread(patch_src)
        if patch_bgr is None:
            raise ValueError(f"Failed to read patch source image: {patch_src}")
        patch_rgb = cv2.cvtColor(patch_bgr, cv2.COLOR_BGR2RGB)
        syn_rgb, syn_mask, centers = self.synth(image_rgb, patch_rgb, class_name=class_name)

        thr = 0.0 if self.mask_threshold is None else float(self.mask_threshold)
        syn_has_mask = float(np.max(syn_mask)) > thr
        syn_image_pil = Image.fromarray(syn_rgb)
        syn_image_sam, syn_resize, syn_original_size = self._preprocess_sam(syn_rgb)
        if syn_has_mask:
            syn_gt_mask = torch.from_numpy(syn_mask.astype(np.float32)).unsqueeze(0).float()
            if self.return_assistant:
                assistant_text = (
                    sample_assistant_mask_only(self.rng)
                    if getattr(self, "assistant_mask_only", False)
                    else sample_assistant_defect(
                        self.rng,
                        class_desc=class_desc,
                        centers=centers,
                        image_hw=syn_rgb.shape[:2],
                    )
                )
            else:
                assistant_text = None
            defect_type = "synthetic"
        else:
            syn_gt_mask = torch.zeros(
                (1, syn_original_size[0], syn_original_size[1]), dtype=torch.float32
            )
            if self.return_assistant:
                assistant_text = (
                    sample_assistant_mask_only(self.rng)
                    if getattr(self, "assistant_mask_only", False)
                    else sample_assistant_normal(self.rng, class_desc=class_desc)
                )
            else:
                assistant_text = None
            defect_type = "good"

        syn_messages = self._build_messages_from_text(
            syn_image_pil,
            user_text,
            assistant_text=assistant_text,
        )
        syn_sample = {
            "image_path": image_path,
            "class_name": class_name,
            "defect_type": defect_type,
            "messages": syn_messages,
            "image_qwen": syn_image_pil,
            "image_sam": syn_image_sam,
            "sam_resize": syn_resize,
            "sam_original_size": syn_original_size,
            "gt_mask": syn_gt_mask,
            "has_mask": syn_has_mask,
            "synthetic": True,
        }

        self.prev_idx = idx
        return {"pair": [normal_sample, syn_sample]}
