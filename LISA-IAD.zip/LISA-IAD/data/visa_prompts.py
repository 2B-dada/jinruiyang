from __future__ import annotations

# VisA uses the same prompt/answer format as MVTec in this repo.
# Only the per-class descriptions differ.

from .mvtec_prompts import ANSWER_LIST, USER_PROMPT, USER_PROMPT_TEMPLATES, sample_assistant, sample_user_prompt

VISA_CLASSES = [
    "candle",
    "capsules",
    "cashew",
    "chewinggum",
    "fryum",
    "macaroni1",
    "macaroni2",
    "pcb1",
    "pcb2",
    "pcb3",
    "pcb4",
    "pipe_fryum",
]

# Ported from AnomalyGPT (code/datasets/visa.py: describles)
DESCRIPTIONS_VISA = {
    "candle": (
        "This is a photo of 4 candles for anomaly detection, every candle should be round, without any "
        "damage, flaw, defect, scratch, hole or broken part."
    ),
    "capsules": (
        "This is a photo of many small capsules for anomaly detection, every capsule is green, should be "
        "without any damage, flaw, defect, scratch, hole or broken part."
    ),
    "cashew": (
        "This is a photo of a cashew for anomaly detection, which should be without any damage, flaw, defect, "
        "scratch, hole or broken part."
    ),
    "chewinggum": (
        "This is a photo of a chewinggum for anomaly detection, which should be white, without any damage, flaw, "
        "defect, scratch, hole or broken part."
    ),
    "fryum": (
        "This is a photo of a fryum for anomaly detection on green background, which should be without any damage, "
        "flaw, defect, scratch, hole or broken part."
    ),
    "macaroni1": (
        "This is a photo of 4 macaronis for anomaly detection, which should be without any damage, flaw, defect, "
        "scratch, hole or broken part."
    ),
    "macaroni2": (
        "This is a photo of 4 macaronis for anomaly detection, which should be without any damage, flaw, defect, "
        "scratch, hole or broken part."
    ),
    "pcb1": "This is a photo of pcb for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part.",
    "pcb2": "This is a photo of pcb for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part.",
    "pcb3": "This is a photo of pcb for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part.",
    "pcb4": "This is a photo of pcb for anomaly detection, which should be without any damage, flaw, defect, scratch, hole or broken part.",
    "pipe_fryum": (
        "This is a photo of a pipe fryum for anomaly detection, which should be without any damage, flaw, defect, "
        "scratch, hole or broken part."
    ),
}

__all__ = [
    "VISA_CLASSES",
    "DESCRIPTIONS_VISA",
    "USER_PROMPT",
    "USER_PROMPT_TEMPLATES",
    "ANSWER_LIST",
    "sample_user_prompt",
    "sample_assistant",
]

