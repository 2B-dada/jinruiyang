from __future__ import annotations

import random

MVTEC_CLASSES = [
    "bottle",
    "cable",
    "capsule",
    "carpet",
    "grid",
    "hazelnut",
    "leather",
    "metal_nut",
    "pill",
    "screw",
    "tile",
    "toothbrush",
    "transistor",
    "wood",
    "zipper",
]


# Ported from AnomalyGPT (code/datasets/mvtec.py: describles)
DESCRIPTIONS_MVTEC = {
    "bottle": (
        "This is a photo of a bottle for anomaly detection, which should be round, without any "
        "damage, flaw, defect, scratch, hole or broken part."
    ),
    "cable": (
        "This is a photo of three cables for anomaly detection, they are green, blue and grey, "
        "which cannot be missed or swapped and should be without any damage, flaw, defect, scratch, "
        "hole or broken part."
    ),
    "capsule": (
        "This is a photo of a capsule for anomaly detection, which should be black and orange, with "
        "print '500', without any damage, flaw, defect, scratch, hole or broken part."
    ),
    "carpet": (
        "This is a photo of carpet for anomaly detection, which should be without any damage, flaw, "
        "defect, scratch, hole or broken part."
    ),
    "grid": (
        "This is a photo of grid for anomaly detection, which should be without any damage, flaw, "
        "defect, scratch, hole or broken part."
    ),
    "hazelnut": (
        "This is a photo of a hazelnut for anomaly detection, which should be without any damage, "
        "flaw, defect, scratch, hole or broken part."
    ),
    "leather": (
        "This is a photo of leather for anomaly detection, which should be brown and without any "
        "damage, flaw, defect, scratch, hole or broken part."
    ),
    "metal_nut": (
        "This is a photo of a metal nut for anomaly detection, which should be without any damage, "
        "flaw, defect, scratch, hole or broken part, and shouldn't be fliped."
    ),
    "pill": (
        "This is a photo of a pill for anomaly detection, which should be white, with print 'FF' and "
        "red patterns, without any damage, flaw, defect, scratch, hole or broken part."
    ),
    "screw": (
        "This is a photo of a screw for anomaly detection, which tail should be sharp, and without "
        "any damage, flaw, defect, scratch, hole or broken part."
    ),
    "tile": (
        "This is a photo of tile for anomaly detection, which should be without any damage, flaw, "
        "defect, scratch, hole or broken part."
    ),
    "toothbrush": (
        "This is a photo of a toothbrush for anomaly detection, which should be without any damage, "
        "flaw, defect, scratch, hole or broken part."
    ),
    "transistor": (
        "This is a photo of a transistor for anomaly detection, which should be without any damage, "
        "flaw, defect, scratch, hole or broken part."
    ),
    "wood": (
        "This is a photo of wood for anomaly detection, which should be brown with patterns, without "
        "any damage, flaw, defect, scratch, hole or broken part."
    ),
    "zipper": (
        "This is a photo of a zipper for anomaly detection, which should be without any damage, flaw, "
        "defect, scratch, hole or broken part."
    ),
}


USER_PROMPT = (
    "{class_desc} You are an expert industrial inspector. "
    "Please locate any defective region on the object surface and provide a segmentation mask. "
    "If there is no defect, return an empty mask."
)

# --- User Prompts (Single Image) ---
# Keep prompts short and stable: the model should reliably output a single <SEG>.
USER_PROMPT_TEMPLATES: list[str] = [USER_PROMPT]

# --- Assistant Answers (Q/A supervision, LISA-style) ---
# Use a single neutral answer template list for BOTH normal and defect cases.
# Rationale (aligned with your IAD goal):
# - We do not want the LM to gate on "defect vs normal" via text, because that gating can be wrong at inference.
# - The mask (empty vs non-empty) is learned via mask supervision, not via the surface-form of the answer text.
ANSWER_LIST: list[str] = [
    "It is <SEG>.",
    "Sure, <SEG>.",
    "Sure, it is <SEG>.",
    "Sure, the segmentation result is <SEG>.",
    "<SEG>.",
]


def sample_user_prompt(rng: random.Random, class_desc: str) -> str:
    template = rng.choice(USER_PROMPT_TEMPLATES)
    return template.format(
        class_desc=class_desc,
    )


def sample_assistant(rng: random.Random) -> str:
    return rng.choice(ANSWER_LIST)
