from __future__ import annotations

from typing import Any

from .collator import Qwen3VLCollator


class PairedQwen3VLCollator:
    """Flatten paired samples into a single batch for Qwen3VLCollator.

    Dataset items can be either:
    - a normal single-sample dict, or
    - a dict with key 'pair' that contains a list/tuple of per-sample dicts.
    """

    def __init__(self, processor, training: bool = True):
        self.base = Qwen3VLCollator(processor, training=training)

    def __call__(self, batch: list[Any]):
        flat = []
        for item in batch:
            if isinstance(item, dict) and "pair" in item:
                pair = item["pair"]
                if not isinstance(pair, (list, tuple)):
                    raise TypeError("Expected item['pair'] to be a list/tuple of samples.")
                flat.extend(list(pair))
            elif isinstance(item, (list, tuple)):
                flat.extend(list(item))
            else:
                flat.append(item)
        return self.base(flat)

