import cv2
import numpy as np

from .synthesis import patch_ex


# Ported from AnomalyGPT (code/datasets/visa.py): VisaDataset.self_sup_args
def build_patchex_args_visa() -> dict:
    return {
        "width_bounds_pct": ((0.03, 0.4), (0.03, 0.4)),
        "intensity_logistic_params": (1 / 12, 24),
        "num_patches": 2,
        "min_object_pct": 0,
        "min_overlap_pct": 0.25,
        "gamma_params": (2, 0.05, 0.03),
        "resize": True,
        "shift": True,
        "same": False,
        "mode": cv2.NORMAL_CLONE,
        "label_mode": "logistic-intensity",
        "skip_background": None,
        "resize_bounds": (0.5, 2.0),
        "verbose": False,
    }


class PatchExVisaSynthesizer:
    """Anomaly synthesis wrapper aligned with AnomalyGPT's VisA settings."""

    def __call__(self, image: np.ndarray, patch_source: np.ndarray, class_name: str | None = None):
        if patch_source.shape[:2] != image.shape[:2]:
            patch_source = cv2.resize(
                patch_source,
                (image.shape[1], image.shape[0]),
                interpolation=cv2.INTER_LINEAR,
            )
        params = build_patchex_args_visa()
        syn, mask, centers = patch_ex(image, patch_source, **params)
        mask = mask[..., 0].astype(np.float32)
        return syn, mask, centers

