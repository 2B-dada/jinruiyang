import cv2
import numpy as np

from .synthesis import patch_ex


# Ported from AnomalyGPT (code/datasets/mvtec.py)
WIDTH_BOUNDS_PCT = {
    "bottle": ((0.03, 0.4), (0.03, 0.4)),
    "cable": ((0.05, 0.4), (0.05, 0.4)),
    "capsule": ((0.03, 0.15), (0.03, 0.4)),
    "hazelnut": ((0.03, 0.35), (0.03, 0.35)),
    "metal_nut": ((0.03, 0.4), (0.03, 0.4)),
    "pill": ((0.03, 0.2), (0.03, 0.4)),
    "screw": ((0.03, 0.12), (0.03, 0.12)),
    "toothbrush": ((0.03, 0.4), (0.03, 0.2)),
    "transistor": ((0.03, 0.4), (0.03, 0.4)),
    "zipper": ((0.03, 0.4), (0.03, 0.2)),
    "carpet": ((0.03, 0.4), (0.03, 0.4)),
    "grid": ((0.03, 0.4), (0.03, 0.4)),
    "leather": ((0.03, 0.4), (0.03, 0.4)),
    "tile": ((0.03, 0.4), (0.03, 0.4)),
    "wood": ((0.03, 0.4), (0.03, 0.4)),
}

# k, x0 pairs for logistic-intensity labels
INTENSITY_LOGISTIC_PARAMS = {
    "bottle": (1 / 12, 24),
    "cable": (1 / 12, 24),
    "capsule": (1 / 2, 4),
    "hazelnut": (1 / 12, 24),
    "metal_nut": (1 / 3, 7),
    "pill": (1 / 3, 7),
    "screw": (1, 3),
    "toothbrush": (1 / 6, 15),
    "transistor": (1 / 6, 15),
    "zipper": (1 / 6, 15),
    "carpet": (1 / 3, 7),
    "grid": (1 / 3, 7),
    "leather": (1 / 3, 7),
    "tile": (1 / 3, 7),
    "wood": (1 / 6, 15),
}

# brightness, threshold pairs
BACKGROUND = {
    "bottle": (200, 60),
    "screw": (200, 60),
    "capsule": (200, 60),
    "zipper": (200, 60),
    "hazelnut": (20, 20),
    "pill": (20, 20),
    "toothbrush": (20, 20),
    "metal_nut": (20, 20),
}

TEXTURES = ["carpet", "grid", "leather", "tile", "wood"]


def build_patchex_args(class_name: str) -> dict:
    args = {
        "width_bounds_pct": WIDTH_BOUNDS_PCT.get(class_name),
        "intensity_logistic_params": INTENSITY_LOGISTIC_PARAMS.get(class_name),
        "num_patches": 2,  # aligned with AnomalyGPT
        "min_object_pct": 0,
        "min_overlap_pct": 0.25,
        "gamma_params": (2, 0.05, 0.03),
        "resize": True,
        "shift": True,
        "same": False,
        "mode": cv2.NORMAL_CLONE,
        "label_mode": "logistic-intensity",
        "skip_background": BACKGROUND.get(class_name),
        "verbose": False,
    }
    if class_name in TEXTURES:
        args["resize_bounds"] = (0.5, 2.0)
    return args


class PatchExMVtecSynthesizer:
    """Anomaly synthesis wrapper aligned with AnomalyGPT's MVTec settings."""

    def __call__(self, image: np.ndarray, patch_source: np.ndarray, class_name: str):
        if patch_source.shape[:2] != image.shape[:2]:
            patch_source = cv2.resize(
                patch_source,
                (image.shape[1], image.shape[0]),
                interpolation=cv2.INTER_LINEAR,
            )
        params = build_patchex_args(class_name)
        syn, mask, centers = patch_ex(image, patch_source, **params)
        mask = mask[..., 0].astype(np.float32)
        return syn, mask, centers

