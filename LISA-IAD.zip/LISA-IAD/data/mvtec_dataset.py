import glob
import os
import random
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import Dataset

from segment_anything.utils.transforms import ResizeLongestSide

from .mvtec_prompts import (
    DESCRIPTIONS_MVTEC,
    USER_PROMPT,
    sample_assistant,
    sample_user_prompt,
)
from .mvtec_synthesis import PatchExMVtecSynthesizer


def _list_images(root_dir: str):
    patterns = ["*.jpg", "*.JPG", "*.jpeg", "*.JPEG", "*.png", "*.PNG"]
    files = []
    for pattern in patterns:
        files.extend(glob.glob(os.path.join(root_dir, pattern)))
    return sorted(files)


class MVtecIADDataset(Dataset):
    pixel_mean = torch.Tensor([123.675, 116.28, 103.53]).view(-1, 1, 1)
    pixel_std = torch.Tensor([58.395, 57.12, 57.375]).view(-1, 1, 1)

    def __init__(
        self,
        root_dir: str,
        split: str = "train",
        categories: list[str] | None = None,
        k_shot: int | None = None,
        anomaly_prob: float = 0.5,
        sam_image_size: int = 1024,
        mask_threshold: float | None = 0.3,
        seed: int = 0,
        return_assistant: bool = True,
    ):
        self.root_dir = root_dir
        self.split = split
        self.categories = categories
        self.k_shot = k_shot
        self.anomaly_prob = anomaly_prob
        self.sam_image_size = sam_image_size
        self.mask_threshold = mask_threshold
        self.return_assistant = return_assistant

        self.rng = random.Random(seed)
        self.synth = PatchExMVtecSynthesizer()
        self.sam_transform = ResizeLongestSide(sam_image_size)

        class_dirs = sorted([d for d in Path(root_dir).iterdir() if d.is_dir()])
        if categories is not None:
            allow = set(categories)
            class_dirs = [d for d in class_dirs if d.name in allow]

        self.samples: list[dict] = []
        if split == "train":
            for class_dir in class_dirs:
                class_name = class_dir.name
                good_dir = class_dir / "train" / "good"
                image_paths = _list_images(str(good_dir))
                if k_shot is not None:
                    self.rng.shuffle(image_paths)
                    image_paths = image_paths[:k_shot]
                for path in image_paths:
                    self.samples.append({"image_path": path, "class_name": class_name})
        elif split == "test":
            for class_dir in class_dirs:
                class_name = class_dir.name
                test_dir = class_dir / "test"
                if not test_dir.exists():
                    continue
                for defect_dir in sorted([d for d in test_dir.iterdir() if d.is_dir()]):
                    defect_type = defect_dir.name
                    for img_path in _list_images(str(defect_dir)):
                        is_good = defect_type == "good"
                        mask_path = None
                        if not is_good:
                            stem = Path(img_path).stem
                            gt_dir = class_dir / "ground_truth" / defect_type
                            mask_path = str(gt_dir / f"{stem}_mask.png")
                        self.samples.append(
                            {
                                "image_path": img_path,
                                "class_name": class_name,
                                "defect_type": defect_type,
                                "is_good": is_good,
                                "mask_path": mask_path,
                            }
                        )
        else:
            raise ValueError(f"Unknown split: {split}")

        if len(self.samples) == 0:
            raise ValueError(f"No samples found in {root_dir} split={split}")

        # AnomalyGPT uses the previous sample as the patch source (after resizing).
        self.prev_idx = self.rng.randrange(len(self.samples)) if self.split == "train" else None

    def __len__(self):
        return len(self.samples)

    def _preprocess_sam(self, image_np: np.ndarray):
        original_size = image_np.shape[:2]
        image_sam = self.sam_transform.apply_image(image_np)
        resize = image_sam.shape[:2]
        image_sam = torch.from_numpy(image_sam).permute(2, 0, 1).contiguous().float()
        image_sam = (image_sam - self.pixel_mean) / self.pixel_std

        h, w = image_sam.shape[-2:]
        pad_h = self.sam_image_size - h
        pad_w = self.sam_image_size - w
        image_sam = F.pad(image_sam, (0, pad_w, 0, pad_h))
        return image_sam, resize, original_size

    def _get_class_desc(self, class_name: str) -> str:
        return DESCRIPTIONS_MVTEC.get(
            class_name,
            f"This is a photo of {class_name} for anomaly detection. The object should be normal.",
        )

    def _build_messages(self, image_pil: Image.Image, class_name: str, assistant_text: str | None):
        class_desc = self._get_class_desc(class_name)
        user_text = USER_PROMPT.format(class_desc=class_desc)
        return self._build_messages_from_text(image_pil, user_text, assistant_text=assistant_text)

    def _build_messages_from_text(
        self, image_pil: Image.Image, user_text: str, assistant_text: str | None
    ):
        user_msg = {
            "role": "user",
            "content": [
                {"type": "image", "image": image_pil},
                {"type": "text", "text": user_text},
            ],
        }
        if assistant_text is None:
            return [user_msg]
        assistant_msg = {"role": "assistant", "content": [{"type": "text", "text": assistant_text}]}
        return [user_msg, assistant_msg]

    def __getitem__(self, idx: int):
        sample = self.samples[idx]
        image_path = sample["image_path"]
        class_name = sample["class_name"]

        image_bgr = cv2.imread(image_path)
        if image_bgr is None:
            raise ValueError(f"Failed to read image: {image_path}")
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

        has_mask = False
        mask = None
        centers = None

        if self.split == "train":
            class_desc = self._get_class_desc(class_name)
            user_text = sample_user_prompt(self.rng, class_desc)

            if self.rng.random() < self.anomaly_prob:
                patch_src = self.samples[self.prev_idx]["image_path"]
                patch_bgr = cv2.imread(patch_src)
                patch_rgb = cv2.cvtColor(patch_bgr, cv2.COLOR_BGR2RGB)
                syn, syn_mask, centers = self.synth(image_rgb, patch_rgb, class_name=class_name)

                # Align with AnomalyGPT: logistic-intensity GT is binarized by gt>0.3 before focal/dice.
                thr = 0.0 if self.mask_threshold is None else float(self.mask_threshold)
                if float(np.max(syn_mask)) > thr:
                    image_rgb = syn
                    mask = syn_mask.astype(np.float32)
                    has_mask = True
                    assistant_text = sample_assistant(self.rng) if self.return_assistant else None
                else:
                    assistant_text = sample_assistant(self.rng) if self.return_assistant else None
            else:
                assistant_text = sample_assistant(self.rng) if self.return_assistant else None

            # Keep AnomalyGPT behavior: use the previous sample as the next patch source.
            self.prev_idx = idx
            defect_type = "synthetic" if has_mask else "good"
        else:
            is_good = bool(sample.get("is_good", True))
            defect_type = sample.get("defect_type", "good")
            if not is_good:
                mask_path = sample.get("mask_path")
                if mask_path and os.path.exists(mask_path):
                    gt = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
                    if gt is None:
                        raise ValueError(f"Failed to read mask: {mask_path}")
                    mask = (gt > 0).astype(np.uint8)
                    has_mask = True
            class_desc = self._get_class_desc(class_name)
            user_text = USER_PROMPT.format(class_desc=class_desc)
            assistant_text = None
            if self.return_assistant:
                assistant_text = sample_assistant(self.rng)

        image_pil = Image.fromarray(image_rgb)
        image_sam, resize, original_size = self._preprocess_sam(image_rgb)

        if mask is None:
            gt_mask = torch.zeros((1, original_size[0], original_size[1]), dtype=torch.float32)
        else:
            gt_mask = torch.from_numpy(mask).unsqueeze(0).float()

        messages = self._build_messages_from_text(image_pil, user_text, assistant_text=assistant_text)

        return {
            "image_path": image_path,
            "class_name": class_name,
            "defect_type": defect_type,
            "messages": messages,
            "image_qwen": image_pil,
            "image_sam": image_sam,
            "sam_resize": resize,
            "sam_original_size": original_size,
            "gt_mask": gt_mask,
            "has_mask": has_mask,
        }
