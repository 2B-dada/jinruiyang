#!/usr/bin/env bash
set -euo pipefail

# Qwen3-VL-4B | VisA | Triplet (normal + same-class syn + DTD syn)
# 60-epoch run + teacher-forcing evaluation for every epoch checkpoint (parallel=5 by default).

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"

export PYTHONUNBUFFERED=1
export TOKENIZERS_PARALLELISM=false

WORKSPACE_ROOT="${WORKSPACE_ROOT:-$(cd -- "${ROOT_DIR}/.." && pwd)}"
export WORKSPACE_ROOT

MODEL_PATH="${MODEL_PATH:-${WORKSPACE_ROOT}/Qwen/Qwen3-VL-4B-Instruct}"
SAM_CKPT="${SAM_CKPT:-${WORKSPACE_ROOT}/sam_vit_h_4b8939.pth}"
VISA_ROOT="${VISA_ROOT:-${WORKSPACE_ROOT}/VisA}"
DTD_ROOT="${DTD_ROOT:-${WORKSPACE_ROOT}/dtd/images}"

CATEGORIES="${CATEGORIES:-}"
K_SHOT="${K_SHOT:-}"

# --- Requested run settings (4B, 60e) ---
EPOCHS="${EPOCHS:-60}"
LR="${LR:-5e-5}"
SAM_LR="${SAM_LR:-3e-4}"
BATCH_SIZE="${BATCH_SIZE:-2}"
GRAD_ACCUM="${GRAD_ACCUM:-8}"

PRECISION="${PRECISION:-bf16}"
NUM_WORKERS="${NUM_WORKERS:-4}"
SEED="${SEED:-42}"

WARMUP_RATIO="${WARMUP_RATIO:-0.1}"
WEIGHT_DECAY="${WEIGHT_DECAY:-0.001}"
GRAD_CLIP="${GRAD_CLIP:-1.0}"

LORA_R="${LORA_R:-32}"
LORA_ALPHA="${LORA_ALPHA:-64}"
LORA_DROPOUT="${LORA_DROPOUT:-0.05}"
LORA_TARGET_MODULES="${LORA_TARGET_MODULES:-q_proj,k_proj,v_proj,o_proj,gate_proj,up_proj,down_proj}"

# --- Evaluation settings (VisA) ---
EVAL_JOBS="${EVAL_JOBS:-5}"
EVAL_SIZE="${EVAL_SIZE:-224}"
EVAL_LIMIT_PER_CLASS="${EVAL_LIMIT_PER_CLASS:-}"
EVAL_SEED="${EVAL_SEED:-42}"
EVAL_EPOCHS="${EVAL_EPOCHS:-}" # optional subset, e.g. "1,5,10-12"

RUN_TAG="${RUN_TAG:-visa_qwen3vl4b_e${EPOCHS}_lr${LR}_lora${LORA_R}_two_source_triplet_anomalygpt_eval}"
STAMP="$(date +%Y%m%d_%H%M%S)"
OUT_DIR="${OUT_DIR:-${ROOT_DIR}/outputs/${RUN_TAG}_${STAMP}}"

if [[ -e "${OUT_DIR}" ]]; then
  echo "[run] Refusing to overwrite existing OUT_DIR=${OUT_DIR}" >&2
  exit 1
fi
mkdir -p "${OUT_DIR}"

cd "${ROOT_DIR}"

echo "[run] ROOT_DIR=${ROOT_DIR}"
echo "[run] WORKSPACE_ROOT=${WORKSPACE_ROOT}"
echo "[run] OUT_DIR=${OUT_DIR}"
echo "[run] MODEL_PATH=${MODEL_PATH}"
echo "[run] SAM_CKPT=${SAM_CKPT}"
echo "[run] VISA_ROOT=${VISA_ROOT}"
echo "[run] DTD_ROOT=${DTD_ROOT}"
echo "[run] CATEGORIES=${CATEGORIES:-<all>} | k_shot=${K_SHOT:-<all>}"
echo "[run] epochs=${EPOCHS} | lr=${LR} | sam_lr=${SAM_LR} | batch_size=${BATCH_SIZE} | grad_accum=${GRAD_ACCUM} | precision=${PRECISION}"
echo "[run] lora: r=${LORA_R} | alpha=${LORA_ALPHA} | dropout=${LORA_DROPOUT} | targets=${LORA_TARGET_MODULES}"
echo "[run] eval: jobs=${EVAL_JOBS} | size=${EVAL_SIZE} | seed=${EVAL_SEED} | limit_per_class=${EVAL_LIMIT_PER_CLASS:-<none>} | strategy=teacher_forcing"
echo "[run] eval_epochs=${EVAL_EPOCHS:-<all>}"

cp -f -- "${SCRIPT_DIR}/$(basename -- "${BASH_SOURCE[0]}")" "${OUT_DIR}/run_script.sh"

TRAIN_ARGS=(
  --model_path "${MODEL_PATH}"
  --sam_checkpoint "${SAM_CKPT}"
  --visa_root "${VISA_ROOT}"
  --output_dir "${OUT_DIR}"
  --epochs "${EPOCHS}"
  --batch_size "${BATCH_SIZE}"
  --grad_accum "${GRAD_ACCUM}"
  --lr "${LR}"
  --sam_lr "${SAM_LR}"
  --warmup_ratio "${WARMUP_RATIO}"
  --weight_decay "${WEIGHT_DECAY}"
  --grad_clip "${GRAD_CLIP}"
  --num_workers "${NUM_WORKERS}"
  --precision "${PRECISION}"
  --seed "${SEED}"
  --save_every 1
  --log_every 50
  --dtd_root "${DTD_ROOT}"
  --lora_r "${LORA_R}"
  --lora_alpha "${LORA_ALPHA}"
  --lora_dropout "${LORA_DROPOUT}"
  --lora_target_modules "${LORA_TARGET_MODULES}"
)

if [[ -n "${CATEGORIES}" ]]; then
  TRAIN_ARGS+=(--categories "${CATEGORIES}")
fi
if [[ -n "${K_SHOT}" ]]; then
  TRAIN_ARGS+=(--k_shot "${K_SHOT}")
fi

echo "[run] Training..."
python train/train_visa_two_source_triplet.py "${TRAIN_ARGS[@]}" 2>&1 | tee "${OUT_DIR}/train.stdout.log"

echo "[run] Evaluating checkpoints (teacher-forcing, parallel=${EVAL_JOBS})..."
EVAL_DIR="${OUT_DIR}/eval_anomalygpt_teacher_forcing_parallel${EVAL_JOBS}"
mkdir -p "${EVAL_DIR}"
cp -f -- "${SCRIPT_DIR}/$(basename -- "${BASH_SOURCE[0]}")" "${EVAL_DIR}/run_script.sh"

SUMMARY_CSV="${EVAL_DIR}/summary.csv"
echo "epoch,mean_i_AUROC,mean_p_AUROC,total_time_sec" > "${SUMMARY_CSV}"

eval_one() {
  local epoch_dir="$1"
  local epoch_name
  local epoch

  epoch_name="$(basename -- "${epoch_dir}")"
  epoch="${epoch_name#epoch_}"

  if [[ ! -f "${epoch_dir}/text_proj.pt" ]]; then
    echo "[eval] Missing: ${epoch_dir}/text_proj.pt" >&2
    return 1
  fi
  if [[ ! -f "${epoch_dir}/sam_mask_decoder.pt" ]]; then
    echo "[eval] Missing: ${epoch_dir}/sam_mask_decoder.pt" >&2
    return 1
  fi

  local eval_log="${EVAL_DIR}/epoch_${epoch}.log"
  local eval_json="${EVAL_DIR}/epoch_${epoch}.json"
  local eval_stdout="${EVAL_DIR}/epoch_${epoch}.stdout.log"

  local eval_args=(
    --model_path "${MODEL_PATH}"
    --sam_checkpoint "${SAM_CKPT}"
    --visa_root "${VISA_ROOT}"
    --lora_path "${epoch_dir}"
    --text_proj "${epoch_dir}/text_proj.pt"
    --sam_mask_decoder "${epoch_dir}/sam_mask_decoder.pt"
    --eval_size "${EVAL_SIZE}"
    --seed "${EVAL_SEED}"
    --output_json "${eval_json}"
    --log_file "${eval_log}"
  )

  if [[ -n "${CATEGORIES}" ]]; then
    eval_args+=(--categories "${CATEGORIES}")
  fi
  if [[ -n "${EVAL_LIMIT_PER_CLASS}" ]]; then
    eval_args+=(--limit_per_class "${EVAL_LIMIT_PER_CLASS}")
  fi

  echo "[run] Eval ${epoch_name}..."
  python eval/AnomalyGPT_eval_visa.py "${eval_args[@]}" > "${eval_stdout}" 2>&1
}

export MODEL_PATH SAM_CKPT VISA_ROOT CATEGORIES
export EVAL_DIR EVAL_SIZE EVAL_LIMIT_PER_CLASS EVAL_SEED
export -f eval_one

epoch_dirs=()
if [[ -n "${EVAL_EPOCHS}" ]]; then
  mapfile -t epochs < <(python - <<'PY'
import os
import re

spec = (os.environ.get("EVAL_EPOCHS") or "").strip()
if not spec:
    raise SystemExit(0)

parts = [p for p in re.split(r"[,\s]+", spec) if p]
epochs = []
seen = set()
for part in parts:
    p = part.strip()
    if not p:
        continue
    p = p.replace("epoch_", "")
    if "-" in p:
        a, b = p.split("-", 1)
        a = a.replace("epoch_", "")
        b = b.replace("epoch_", "")
        start = int(a)
        end = int(b)
        step = 1 if start <= end else -1
        for e in range(start, end + step, step):
            if e not in seen:
                epochs.append(e)
                seen.add(e)
    else:
        e = int(p)
        if e not in seen:
            epochs.append(e)
            seen.add(e)

for e in epochs:
    print(e)
PY
  )
  for epoch in "${epochs[@]}"; do
    epoch_dir="${OUT_DIR}/epoch_${epoch}"
    if [[ ! -d "${epoch_dir}" ]]; then
      echo "[run] Missing checkpoint dir: ${epoch_dir}" >&2
      exit 1
    fi
    epoch_dirs+=("${epoch_dir}")
  done
else
  for ((epoch=1; epoch<=EPOCHS; epoch++)); do
    epoch_dir="${OUT_DIR}/epoch_${epoch}"
    if [[ ! -d "${epoch_dir}" ]]; then
      echo "[run] Missing checkpoint dir: ${epoch_dir}" >&2
      exit 1
    fi
    epoch_dirs+=("${epoch_dir}")
  done
fi

printf '%s\n' "${epoch_dirs[@]}" | xargs -P "${EVAL_JOBS}" -I {} bash -c 'set -euo pipefail; eval_one "$1"' _ {}

python - <<PY >> "${SUMMARY_CSV}"
import glob
import json
import os
import re

eval_dir = r"${EVAL_DIR}"
paths = glob.glob(os.path.join(eval_dir, "epoch_*.json"))

def _epoch(p: str) -> int:
    m = re.search(r"epoch_(\\d+)\\.json$", p)
    return int(m.group(1)) if m else 0

for path in sorted(paths, key=_epoch):
    with open(path, "r", encoding="utf-8") as f:
        d = json.load(f)
    epoch = _epoch(path)
    i_auc = d.get("mean_i_AUROC")
    p_auc = d.get("mean_p_AUROC")
    t = d.get("total_time_sec")
    print(f"{epoch},{i_auc},{p_auc},{t}")
PY

echo "[run] Done."
echo "  - Train logs: ${OUT_DIR}/train.log , ${OUT_DIR}/train.stdout.log"
echo "  - Eval logs/json: ${EVAL_DIR}/"
echo "  - Summary: ${SUMMARY_CSV}"

