from typing import List, Optional

import torch
import torch.nn as nn

from transformers import Qwen3VLForConditionalGeneration

from segment_anything import build_sam_vit_h

from utils.losses import dice_loss, sigmoid_focal_loss


class LISAQwenForSegmentation(nn.Module):
    def __init__(
        self,
        qwen_model: Qwen3VLForConditionalGeneration,
        sam_checkpoint: str,
        seg_token_idx: int,
        out_dim: Optional[int] = None,
        train_mask_decoder: bool = True,
        gt_mask_threshold: Optional[float] = 0.3,
        mask_loss_on_normals: bool = True,
        ce_loss_weight: float = 1.0,
        focal_loss_weight: float = 3.0,
        dice_loss_weight: float = 0.5,
    ):
        super().__init__()
        self.qwen = qwen_model
        self.seg_token_idx = seg_token_idx
        self.gt_mask_threshold = gt_mask_threshold
        self.mask_loss_on_normals = mask_loss_on_normals
        self.ce_loss_weight = ce_loss_weight
        self.focal_loss_weight = focal_loss_weight
        self.dice_loss_weight = dice_loss_weight

        hidden_size = getattr(self.qwen.config, "hidden_size", None)
        if hidden_size is None:
            hidden_size = self.qwen.config.text_config.hidden_size

        self.sam = build_sam_vit_h(sam_checkpoint)
        for param in self.sam.parameters():
            param.requires_grad = False
        if train_mask_decoder:
            self.sam.mask_decoder.train()
            for param in self.sam.mask_decoder.parameters():
                param.requires_grad = True

        sam_embed_dim = self.sam.prompt_encoder.embed_dim
        out_dim = sam_embed_dim if out_dim is None else out_dim

        self.text_proj = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.GELU(),
            nn.Linear(hidden_size, out_dim),
            nn.Dropout(0.0),
        )

    def train(self, mode: bool = True):
        super().train(mode)

        # Keep SAM's frozen components in eval mode to avoid any train-time behavior
        # (e.g., dropout / running-stat updates) affecting image features.
        self.sam.image_encoder.eval()
        self.sam.prompt_encoder.eval()

        if any(p.requires_grad for p in self.sam.mask_decoder.parameters()):
            self.sam.mask_decoder.train(mode)
        else:
            self.sam.mask_decoder.eval()

        return self

    def get_sam_image_embeddings(self, sam_images: torch.Tensor) -> torch.Tensor:
        with torch.no_grad():
            image_embeddings = []
            for i in range(sam_images.shape[0]):
                emb = self.sam.image_encoder(sam_images[i].unsqueeze(0))
                image_embeddings.append(emb)
            image_embeddings = torch.cat(image_embeddings, dim=0)
        return image_embeddings

    def _extract_seg_embeddings(
        self,
        input_ids: torch.Tensor,
        last_hidden: torch.Tensor,
        *,
        labels: Optional[torch.Tensor] = None,
        assistant_mask: Optional[torch.Tensor] = None,
        assistant_start: Optional[int | torch.Tensor] = None,
    ) -> List[Optional[torch.Tensor]]:
        assert last_hidden.shape[1] == input_ids.shape[1], (
            last_hidden.shape,
            input_ids.shape,
        )
        seg_token_mask = input_ids == self.seg_token_idx

        if assistant_mask is not None:
            if assistant_mask.shape != input_ids.shape:
                raise ValueError(
                    f"assistant_mask must have same shape as input_ids, got {assistant_mask.shape} vs {input_ids.shape}"
                )
            seg_token_mask = seg_token_mask & assistant_mask.to(device=input_ids.device, dtype=torch.bool)
        elif labels is not None:
            if labels.shape != input_ids.shape:
                raise ValueError(
                    f"labels must have same shape as input_ids, got {labels.shape} vs {input_ids.shape}"
                )
            # Training-time: restrict <SEG> extraction to assistant tokens (labels != -100).
            seg_token_mask = seg_token_mask & (labels != -100)
        elif assistant_start is not None:
            # Inference-time: restrict <SEG> extraction to tokens at/after assistant_start (e.g., prompt_len).
            if isinstance(assistant_start, int):
                start = torch.full(
                    (input_ids.shape[0],),
                    int(assistant_start),
                    device=input_ids.device,
                    dtype=torch.long,
                )
            else:
                start = assistant_start.to(device=input_ids.device, dtype=torch.long).view(-1)
                if start.shape[0] != input_ids.shape[0]:
                    raise ValueError(
                        f"assistant_start must be int or shape [batch], got {start.shape} for batch={input_ids.shape[0]}"
                    )
            positions = torch.arange(input_ids.shape[1], device=input_ids.device).view(1, -1)
            seg_token_mask = seg_token_mask & (positions >= start.view(-1, 1))

        seg_embeddings = []
        for i in range(input_ids.shape[0]):
            positions = seg_token_mask[i].nonzero(as_tuple=True)[0]
            if positions.numel() == 0:
                seg_embeddings.append(None)
                continue
            # Single-mask setting: use the first <SEG> token if multiple are present.
            pos = positions[0].item()
            emb = last_hidden[i, pos].float().unsqueeze(0)
            seg_embeddings.append(self.text_proj(emb))
        return seg_embeddings

    def _predict_masks(
        self,
        seg_embeddings: List[Optional[torch.Tensor]],
        sam_images: torch.Tensor,
        sam_resize: List[tuple],
        sam_original_size: List[tuple],
    ):
        pred_masks = []
        if all(emb is None for emb in seg_embeddings):
            return [None for _ in seg_embeddings]

        image_embeddings = self.get_sam_image_embeddings(sam_images)
        for i, emb in enumerate(seg_embeddings):
            if emb is None:
                pred_masks.append(None)
                continue
            sparse_embeddings, dense_embeddings = self.sam.prompt_encoder(
                points=None,
                boxes=None,
                masks=None,
                text_embeds=emb.unsqueeze(1),
            )
            sparse_embeddings = sparse_embeddings.to(emb.dtype)
            dense_embeddings = dense_embeddings.to(emb.dtype)
            low_res_masks, _ = self.sam.mask_decoder(
                image_embeddings=image_embeddings[i].unsqueeze(0),
                image_pe=self.sam.prompt_encoder.get_dense_pe(),
                sparse_prompt_embeddings=sparse_embeddings,
                dense_prompt_embeddings=dense_embeddings,
                multimask_output=False,
            )
            pred_mask = self.sam.postprocess_masks(
                low_res_masks,
                input_size=sam_resize[i],
                original_size=sam_original_size[i],
            )
            pred_masks.append(pred_mask[:, 0])
        return pred_masks

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        pixel_values: Optional[torch.Tensor],
        image_grid_thw: Optional[torch.Tensor],
        sam_images: torch.Tensor,
        sam_resize: List[tuple],
        sam_original_size: List[tuple],
        labels: Optional[torch.Tensor] = None,
        gt_masks: Optional[List[torch.Tensor]] = None,
        has_mask: Optional[torch.Tensor] = None,
    ):
        qwen_inputs = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "output_hidden_states": True,
            "return_dict": True,
        }
        if pixel_values is not None:
            qwen_inputs["pixel_values"] = pixel_values
        if image_grid_thw is not None:
            qwen_inputs["image_grid_thw"] = image_grid_thw
        if labels is not None:
            qwen_inputs["labels"] = labels

        outputs = self.qwen(**qwen_inputs)
        last_hidden = outputs.hidden_states[-1]

        seg_embeddings = self._extract_seg_embeddings(input_ids, last_hidden, labels=labels)
        pred_masks = self._predict_masks(
            seg_embeddings, sam_images, sam_resize, sam_original_size
        )

        ce_loss = outputs.loss * self.ce_loss_weight if labels is not None else None

        mask_focal_loss = torch.tensor(0.0, device=input_ids.device)
        mask_dice_loss = torch.tensor(0.0, device=input_ids.device)
        num_focal_masks = 0
        num_dice_masks = 0
        if gt_masks is not None:
            for i in range(len(pred_masks)):
                if has_mask is not None and (not bool(has_mask[i])) and (not self.mask_loss_on_normals):
                    continue
                pred = pred_masks[i]
                if pred is None:
                    continue
                gt = gt_masks[i].to(pred.device)
                if self.gt_mask_threshold is not None:
                    gt = (gt > float(self.gt_mask_threshold)).to(dtype=pred.dtype)
                if pred.shape[0] != gt.shape[0]:
                    pred = pred[: gt.shape[0]]
                mask_focal_loss += sigmoid_focal_loss(
                    pred, gt, alpha=0.25, gamma=2.0, reduction="mean"
                ) * gt.shape[0]
                num_focal_masks += gt.shape[0]

                # Dice loss is only computed on defect samples (non-empty GT mask).
                # This avoids the "empty-mask Dice dominates and pushes everything to black" failure mode,
                # and tends to better match Pixel-AUROC's ranking objective when focal is computed for all samples.
                if torch.sum(gt).item() > 0:
                    mask_dice_loss += dice_loss(pred, gt) * gt.shape[0]
                    num_dice_masks += gt.shape[0]

        if num_focal_masks > 0:
            mask_focal_loss = self.focal_loss_weight * mask_focal_loss / (num_focal_masks + 1e-8)
        else:
            mask_focal_loss = torch.tensor(0.0, device=input_ids.device)

        if num_dice_masks > 0:
            mask_dice_loss = self.dice_loss_weight * mask_dice_loss / (num_dice_masks + 1e-8)
        else:
            mask_dice_loss = torch.tensor(0.0, device=input_ids.device)

        if (num_focal_masks + num_dice_masks) > 0:
            mask_loss = mask_focal_loss + mask_dice_loss
        else:
            mask_loss = torch.tensor(0.0, device=input_ids.device)

        if ce_loss is not None:
            loss = ce_loss + mask_loss
        else:
            loss = mask_loss

        return {
            "loss": loss,
            "ce_loss": ce_loss,
            "mask_focal_loss": mask_focal_loss,
            "mask_dice_loss": mask_dice_loss,
            "mask_loss": mask_loss,
            "pred_masks": pred_masks,
        }

    @torch.no_grad()
    def predict_masks_from_ids(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        pixel_values: Optional[torch.Tensor],
        image_grid_thw: Optional[torch.Tensor],
        sam_images: torch.Tensor,
        sam_resize: List[tuple],
        sam_original_size: List[tuple],
        assistant_start: Optional[int | torch.Tensor] = None,
    ):
        qwen_inputs = {
            "input_ids": input_ids,
            "attention_mask": attention_mask,
            "output_hidden_states": True,
            "return_dict": True,
        }
        if pixel_values is not None:
            qwen_inputs["pixel_values"] = pixel_values
        if image_grid_thw is not None:
            qwen_inputs["image_grid_thw"] = image_grid_thw

        outputs = self.qwen(**qwen_inputs)
        last_hidden = outputs.hidden_states[-1]
        seg_embeddings = self._extract_seg_embeddings(
            input_ids,
            last_hidden,
            assistant_start=assistant_start,
        )
        pred_masks = self._predict_masks(
            seg_embeddings, sam_images, sam_resize, sam_original_size
        )
        return pred_masks
