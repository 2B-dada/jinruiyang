from __future__ import annotations

import numpy as np


def _rankdata_average_ties(x: np.ndarray) -> np.ndarray:
    """1-based ranks with average ranks for ties (scikit-learn compatible for ROC-AUC)."""
    x = np.asarray(x)
    if x.ndim != 1:
        x = x.reshape(-1)
    n = int(x.shape[0])
    if n == 0:
        return np.zeros((0,), dtype=np.float64)

    order = np.argsort(x, kind="mergesort")
    x_sorted = x[order]

    ranks = np.empty((n,), dtype=np.float64)
    start = 0
    while start < n:
        end = start
        v = x_sorted[start]
        while (end + 1) < n and x_sorted[end + 1] == v:
            end += 1
        # Average of 1-based ranks in [start, end].
        avg_rank = 0.5 * (start + end) + 1.0
        ranks[order[start : end + 1]] = avg_rank
        start = end + 1

    return ranks


def roc_auc_score(y_true, y_score) -> float:
    """Binary ROC-AUC (AUROC) aligned with AnomalyGPT's sklearn.metrics.roc_auc_score usage.

    Notes:
    - This implements the rank-based AUROC (Mann–Whitney U statistic) with tie handling,
      which matches sklearn's roc_auc_score for the binary case.
    - y_true is binarized by (y_true > 0.5).
    """
    y_true = np.asarray(y_true).reshape(-1)
    y_score = np.asarray(y_score, dtype=np.float64).reshape(-1)
    if y_true.shape[0] != y_score.shape[0]:
        raise ValueError(f"y_true and y_score must have same length, got {y_true.shape} vs {y_score.shape}")

    y_bin = (y_true > 0.5).astype(np.uint8, copy=False)
    n_pos = int(y_bin.sum())
    n = int(y_bin.shape[0])
    n_neg = n - n_pos
    if n_pos == 0 or n_neg == 0:
        raise ValueError("Only one class present in y_true; ROC AUC score is not defined.")

    ranks = _rankdata_average_ties(y_score)
    sum_pos = float(ranks[y_bin == 1].sum())
    auc = (sum_pos - (n_pos * (n_pos + 1) / 2.0)) / (n_pos * n_neg)
    return float(auc)

