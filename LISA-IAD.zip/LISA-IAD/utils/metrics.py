import numpy as np


def roc_auc_score(scores, labels):
    scores = np.asarray(scores).reshape(-1)
    labels = np.asarray(labels).reshape(-1).astype(np.int64)
    pos = labels.sum()
    neg = labels.shape[0] - pos
    if pos == 0 or neg == 0:
        return float("nan")

    order = np.argsort(-scores)
    labels = labels[order]
    tps = np.cumsum(labels == 1)
    fps = np.cumsum(labels == 0)
    tpr = tps / pos
    fpr = fps / neg
    return np.trapz(tpr, fpr)


class PixelAUCAccumulator:
    def __init__(self, bins: int = 2048):
        if bins < 16:
            raise ValueError("bins must be >= 16")
        self.bins = int(bins)
        self.hist_pos = np.zeros(self.bins, dtype=np.float64)
        self.hist_all = np.zeros(self.bins, dtype=np.float64)

    def update(self, pred_prob: np.ndarray, gt_mask: np.ndarray):
        pred = np.asarray(pred_prob, dtype=np.float32).reshape(-1)
        gt = np.asarray(gt_mask).reshape(-1)

        if pred.shape[0] != gt.shape[0]:
            raise ValueError(f"pred_prob and gt_mask must have same size, got {pred.shape} vs {gt.shape}")

        if pred.size == 0:
            return

        pred = np.clip(pred, 0.0, 1.0)
        gt_bin = gt > 0.5

        bin_idx = (pred * (self.bins - 1)).astype(np.int64, copy=False)
        self.hist_all += np.bincount(bin_idx, minlength=self.bins)
        if bool(np.any(gt_bin)):
            self.hist_pos += np.bincount(bin_idx[gt_bin], minlength=self.bins)

    def compute(self) -> float:
        pos = float(self.hist_pos.sum())
        neg = float((self.hist_all - self.hist_pos).sum())
        if pos == 0.0 or neg == 0.0:
            return float("nan")

        tp = np.concatenate([[0.0], np.cumsum(self.hist_pos[::-1])])
        hist_neg = self.hist_all - self.hist_pos
        fp = np.concatenate([[0.0], np.cumsum(hist_neg[::-1])])
        tpr = tp / pos
        fpr = fp / neg
        return float(np.trapz(tpr, fpr))


def compute_pixel_auc(pred_masks, gt_masks):
    preds = []
    gts = []
    for pred, gt in zip(pred_masks, gt_masks):
        preds.append(pred.reshape(-1))
        gts.append(gt.reshape(-1))
    preds = np.concatenate(preds, axis=0)
    gts = np.concatenate(gts, axis=0)
    return roc_auc_score(preds, gts)


def compute_image_auc(image_scores, image_labels):
    return roc_auc_score(np.array(image_scores), np.array(image_labels))
