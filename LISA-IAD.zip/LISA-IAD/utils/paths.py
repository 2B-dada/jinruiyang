from __future__ import annotations

import os
from pathlib import Path


_REPO_ROOT = Path(__file__).resolve().parents[1]


def repo_root() -> Path:
    """Return the LISA-IAD repo root directory."""
    return _REPO_ROOT


def workspace_root() -> Path:
    """Return a configurable workspace root where datasets/models live.

    Resolution order:
    1) $LISA_IAD_WORKSPACE_ROOT
    2) $WORKSPACE_ROOT
    3) parent directory of this repo (../)
    """
    env = os.environ.get("LISA_IAD_WORKSPACE_ROOT") or os.environ.get("WORKSPACE_ROOT")
    if env:
        return Path(env).expanduser().resolve()
    return _REPO_ROOT.parent


def resolve_path(path: str | os.PathLike[str], *, base_dir: Path | None = None) -> Path:
    """Resolve a (possibly relative) path against base_dir (defaults to workspace_root)."""
    p = Path(path).expanduser()
    if p.is_absolute():
        return p
    base = workspace_root() if base_dir is None else Path(base_dir).expanduser().resolve()
    return (base / p).resolve()

