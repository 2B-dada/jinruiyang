import argparse
import hashlib
import json
import logging
import os
import random
import sys
import time
from pathlib import Path

ROOT_DIR = os.path.dirname(os.path.dirname(__file__))
if ROOT_DIR not in sys.path:
    sys.path.append(ROOT_DIR)

import numpy as np
import torch
import torch.nn.functional as F
from peft import PeftModel
from tqdm import tqdm
from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

from data.mvtec_dataset import MVtecIADDataset
from data.mvtec_prompts import DESCRIPTIONS_MVTEC, TEACHER_FORCING_ASSISTANT_STUB, sample_user_prompt
from model import LISAQwenForSegmentation
from utils.AnomalyGPT_metrics import roc_auc_score


def parse_args():
    parser = argparse.ArgumentParser(
        description="AnomalyGPT-aligned evaluation on MVTec-AD for LISA-IAD (Pixel-AUC/Image-AUC)."
    )
    parser.add_argument("--model_path", type=str, required=True, help="Path to Qwen3-VL model")
    parser.add_argument("--sam_checkpoint", type=str, required=True, help="Path to SAM checkpoint")
    parser.add_argument("--mvtec_root", type=str, required=True, help="Path to MVTec-AD dataset")
    parser.add_argument(
        "--categories",
        type=str,
        default=None,
        help="Comma-separated MVTec categories (default: all).",
    )

    parser.add_argument("--lora_path", type=str, default=None)
    parser.add_argument("--text_proj", type=str, required=True)
    parser.add_argument("--sam_mask_decoder", type=str, required=True)

    parser.add_argument(
        "--inference_strategy",
        type=str,
        default="teacher_forcing",
        choices=["teacher_forcing", "generate"],
        help="teacher_forcing: no generation, force an assistant stub containing <SEG> (stable); "
        "generate: autoregressive generation then extract/append <SEG>.",
    )
    parser.add_argument("--max_new_tokens", type=int, default=64)

    # AnomalyGPT eval runs at 224x224, and uses anomaly_map.max() as image score.
    parser.add_argument("--eval_size", type=int, default=224, help="Resize pred/gt masks to this size (default: 224).")
    parser.add_argument(
        "--prompt_source",
        type=str,
        default="mvtec_templates",
        choices=["mvtec_templates", "anomalygpt_question"],
        help="mvtec_templates: sample diverse prompts from mvtec_prompts.py (matches training); "
        "anomalygpt_question: use class_desc + --user_question (legacy AnomalyGPT-style).",
    )
    parser.add_argument(
        "--user_question",
        type=str,
        default="Is there any anomaly in the image?",
        help="Used only when --prompt_source=anomalygpt_question.",
    )
    parser.add_argument(
        "--assistant_stub",
        type=str,
        default=TEACHER_FORCING_ASSISTANT_STUB,
        help="Assistant stub used for teacher-forcing inference.",
    )

    parser.add_argument("--limit_per_class", type=int, default=None, help="Limit number of test samples per class.")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output_json", type=str, default=None)
    parser.add_argument("--log_file", type=str, default=None)
    return parser.parse_args()


def setup_logger(log_file: str | None) -> logging.Logger:
    logger = logging.getLogger("AnomalyGPT_eval_mvtec")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    if log_file:
        log_dir = os.path.dirname(log_file)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)

    logger.propagate = False
    return logger


def _resize_2d(x_hw: torch.Tensor, size: int) -> torch.Tensor:
    x = x_hw
    if x.dim() != 2:
        raise ValueError(f"Expected (H,W) tensor, got {tuple(x.shape)}")
    x = x.unsqueeze(0).unsqueeze(0)  # 1x1xHxW
    x = F.interpolate(x, size=(int(size), int(size)), mode="bilinear", align_corners=False)
    return x[0, 0]


def _build_user_messages(*, image, user_text: str):
    return [
        {
            "role": "user",
            "content": [
                {"type": "image", "image": image},
                {"type": "text", "text": user_text},
            ],
        }
    ]


def _rng_for_image_path(seed: int, image_path: str) -> random.Random:
    digest = hashlib.md5(str(image_path).encode("utf-8")).digest()
    s = (int(seed) + int.from_bytes(digest[:4], "little")) % (2**32)
    return random.Random(int(s))


@torch.no_grad()
def _predict_one(
    *,
    model: LISAQwenForSegmentation,
    processor: AutoProcessor,
    tokenizer,
    seg_token_idx: int,
    sample: dict,
    user_text: str,
    inference_strategy: str,
    assistant_stub: str,
    max_new_tokens: int,
    device: torch.device,
) -> torch.Tensor:
    """Return predicted probability map in original image size as (H,W) float tensor in [0,1]."""
    user_only = _build_user_messages(image=sample["image_qwen"], user_text=user_text)

    if inference_strategy == "teacher_forcing":
        prompt_inputs = processor.apply_chat_template(
            user_only,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
            padding=True,
        )
        prompt_len = int(prompt_inputs["input_ids"].shape[1])

        assistant_msg = {"role": "assistant", "content": [{"type": "text", "text": assistant_stub}]}
        full_messages = list(user_only) + [assistant_msg]
        inputs = processor.apply_chat_template(
            full_messages,
            tokenize=True,
            add_generation_prompt=False,
            return_dict=True,
            return_tensors="pt",
            padding=True,
        )
        input_ids = inputs["input_ids"].to(device)
        attention_mask = inputs["attention_mask"].to(device)
        pixel_values = inputs.get("pixel_values")
        image_grid_thw = inputs.get("image_grid_thw")
        if pixel_values is not None:
            pixel_values = pixel_values.to(device)
        if image_grid_thw is not None:
            image_grid_thw = image_grid_thw.to(device)

        pred_masks = model.predict_masks_from_ids(
            input_ids=input_ids,
            attention_mask=attention_mask,
            pixel_values=pixel_values,
            image_grid_thw=image_grid_thw,
            sam_images=sample["image_sam"].unsqueeze(0).to(device),
            sam_resize=[sample["sam_resize"]],
            sam_original_size=[sample["sam_original_size"]],
            assistant_start=prompt_len,
        )
        pred_mask = pred_masks[0]
    else:
        inputs = processor.apply_chat_template(
            user_only,
            tokenize=True,
            add_generation_prompt=True,
            return_dict=True,
            return_tensors="pt",
            padding=True,
        )
        input_ids = inputs["input_ids"].to(device)
        attention_mask = inputs["attention_mask"].to(device)
        pixel_values = inputs.get("pixel_values")
        image_grid_thw = inputs.get("image_grid_thw")
        if pixel_values is not None:
            pixel_values = pixel_values.to(device)
        if image_grid_thw is not None:
            image_grid_thw = image_grid_thw.to(device)

        generated = model.qwen.generate(
            input_ids=input_ids,
            attention_mask=attention_mask,
            pixel_values=pixel_values,
            image_grid_thw=image_grid_thw,
            max_new_tokens=int(max_new_tokens),
        )
        gen_ids = generated[0]
        prompt_len = int(input_ids.shape[1])
        full_ids = gen_ids.unsqueeze(0)
        assistant_start = int(prompt_len)

        # Align with existing eval: if <SEG> is missing in assistant tokens, append one.
        if not (full_ids[0, assistant_start:] == seg_token_idx).any():
            seg = torch.tensor([[seg_token_idx]], device=full_ids.device, dtype=full_ids.dtype)
            eos_id = tokenizer.eos_token_id
            if eos_id is not None and int(full_ids[0, -1].item()) == int(eos_id):
                full_ids = torch.cat([full_ids[:, :-1], seg, full_ids[:, -1:]], dim=1)
            else:
                full_ids = torch.cat([full_ids, seg], dim=1)

        full_mask = torch.ones_like(full_ids)
        pred_masks = model.predict_masks_from_ids(
            input_ids=full_ids.to(device),
            attention_mask=full_mask.to(device),
            pixel_values=pixel_values,
            image_grid_thw=image_grid_thw,
            sam_images=sample["image_sam"].unsqueeze(0).to(device),
            sam_resize=[sample["sam_resize"]],
            sam_original_size=[sample["sam_original_size"]],
            assistant_start=assistant_start,
        )
        pred_mask = pred_masks[0]

    if pred_mask is None:
        h, w = sample["gt_mask"].shape[-2:]
        return torch.zeros((h, w), dtype=torch.float32, device="cpu")

    pred_prob = torch.sigmoid(pred_mask[0]).detach().float().cpu()  # (H,W)
    return pred_prob


def main():
    args = parse_args()
    logger = setup_logger(args.log_file)
    logger.info("Args: %s", json.dumps(vars(args), ensure_ascii=False, indent=2))

    categories = None
    if args.categories:
        categories = [c.strip() for c in args.categories.split(",") if c.strip()]

    processor = AutoProcessor.from_pretrained(args.model_path)
    tokenizer = processor.tokenizer
    num_added = tokenizer.add_tokens(["<SEG>"])
    seg_token_idx = tokenizer("<SEG>", add_special_tokens=False).input_ids[0]

    qwen = Qwen3VLForConditionalGeneration.from_pretrained(args.model_path, dtype="auto")
    if num_added > 0:
        qwen.resize_token_embeddings(len(tokenizer))
    if args.lora_path:
        qwen = PeftModel.from_pretrained(qwen, args.lora_path)

    model = LISAQwenForSegmentation(
        qwen_model=qwen,
        sam_checkpoint=args.sam_checkpoint,
        seg_token_idx=seg_token_idx,
        train_mask_decoder=True,
    )
    model.text_proj.load_state_dict(torch.load(args.text_proj, map_location="cpu"))
    model.sam.mask_decoder.load_state_dict(torch.load(args.sam_mask_decoder, map_location="cpu"))

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    model.eval()
    logger.info("Device: %s", device)

    dataset = MVtecIADDataset(
        root_dir=args.mvtec_root,
        split="test",
        categories=categories,
        return_assistant=False,
    )

    # Build per-class indices without loading images.
    indices_by_class: dict[str, list[int]] = {}
    for idx, meta in enumerate(getattr(dataset, "samples", [])):
        cname = meta.get("class_name")
        if not cname:
            continue
        indices_by_class.setdefault(str(cname), []).append(int(idx))

    rng = np.random.default_rng(int(args.seed))
    per_class_results: dict[str, dict] = {}
    p_auc_list = []
    i_auc_list = []

    eval_start = time.time()
    for cname in sorted(indices_by_class.keys()):
        idxs = indices_by_class[cname]
        if args.limit_per_class is not None and int(args.limit_per_class) > 0 and len(idxs) > int(args.limit_per_class):
            idxs = rng.choice(idxs, size=int(args.limit_per_class), replace=False).tolist()

        pixel_pred_flat = []
        pixel_label_flat = []
        image_pred = []
        image_label = []

        class_desc = DESCRIPTIONS_MVTEC.get(
            cname,
            f"This is a photo of {cname} for anomaly detection, and the object should be normal.",
        )

        pbar = tqdm(idxs, desc=f"[{cname}] eval", dynamic_ncols=True)
        for idx in pbar:
            sample = dataset[int(idx)]
            if str(args.prompt_source) == "anomalygpt_question":
                user_text = f"{class_desc} {str(args.user_question).strip()}".strip()
            else:
                rng_prompt = _rng_for_image_path(int(args.seed), sample["image_path"])
                user_text = sample_user_prompt(rng_prompt, class_desc)
            gt_mask = sample["gt_mask"][0].float()  # (H,W) in {0,1}
            pred_prob = _predict_one(
                model=model,
                processor=processor,
                tokenizer=tokenizer,
                seg_token_idx=seg_token_idx,
                sample=sample,
                user_text=user_text,
                inference_strategy=str(args.inference_strategy),
                assistant_stub=str(args.assistant_stub),
                max_new_tokens=int(args.max_new_tokens),
                device=device,
            )

            pred_224 = _resize_2d(pred_prob, int(args.eval_size))
            gt_224 = _resize_2d(gt_mask.cpu(), int(args.eval_size))
            gt_bin = (gt_224 > 0.1).to(dtype=torch.float32)  # match AnomalyGPT thresholding

            pixel_pred_flat.append(pred_224.numpy().reshape(-1))
            pixel_label_flat.append(gt_bin.numpy().reshape(-1))
            image_pred.append(float(pred_224.max().item()))
            image_label.append(1 if bool(sample["has_mask"]) else 0)

        pixel_pred_flat = np.concatenate(pixel_pred_flat, axis=0) if pixel_pred_flat else np.array([], dtype=np.float32)
        pixel_label_flat = np.concatenate(pixel_label_flat, axis=0) if pixel_label_flat else np.array([], dtype=np.float32)
        image_pred = np.asarray(image_pred, dtype=np.float64)
        image_label = np.asarray(image_label, dtype=np.float64)

        p_auc = roc_auc_score(pixel_label_flat, pixel_pred_flat)
        i_auc = roc_auc_score(image_label, image_pred)

        p_auroc = round(float(p_auc) * 100.0, 2)
        i_auroc = round(float(i_auc) * 100.0, 2)

        p_auc_list.append(p_auroc)
        i_auc_list.append(i_auroc)

        per_class_results[cname] = {
            "num_samples": int(len(idxs)),
            "pixel_auroc": p_auroc,
            "image_auroc": i_auroc,
        }
        logger.info("%s | i_AUROC=%.2f | p_AUROC=%.2f | n=%d", cname, i_auroc, p_auroc, len(idxs))

    mean_i = float(np.mean(i_auc_list)) if i_auc_list else float("nan")
    mean_p = float(np.mean(p_auc_list)) if p_auc_list else float("nan")
    total_time = time.time() - eval_start

    summary = {
        "inference_strategy": str(args.inference_strategy),
        "eval_size": int(args.eval_size),
        "prompt_source": str(args.prompt_source),
        "user_question": str(args.user_question),
        "assistant_stub": str(args.assistant_stub),
        "limit_per_class": args.limit_per_class,
        "seed": int(args.seed),
        "mean_i_AUROC": mean_i,
        "mean_p_AUROC": mean_p,
        "per_class": per_class_results,
        "total_time_sec": float(total_time),
    }
    logger.info("Mean i_AUROC: %.2f", mean_i)
    logger.info("Mean p_AUROC: %.2f", mean_p)

    if args.output_json:
        out_path = str(args.output_json)
        out_dir = os.path.dirname(out_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, ensure_ascii=False, indent=2)
        logger.info("Wrote: %s", out_path)

    print("i_AUROC:", mean_i)
    print("p_AUROC:", mean_p)


if __name__ == "__main__":
    main()
