from __future__ import annotations

import random
from typing import Iterable, Sequence

VISA_CLASSES = [
    "candle",
    "capsules",
    "cashew",
    "chewinggum",
    "fryum",
    "macaroni1",
    "macaroni2",
    "pcb1",
    "pcb2",
    "pcb3",
    "pcb4",
    "pipe_fryum",
]


# VisA class descriptions (aligned with AnomalyGPT style)
DESCRIPTIONS_VISA = {
    "candle": (
        "This is a photo of a candle for anomaly detection, which should have smooth wax surface "
        "without any damage, flaw, defect, scratch, hole, crack, bubble or broken part."
    ),
    "capsules": (
        "This is a photo of capsules for anomaly detection, which should be intact and properly sealed, "
        "without any damage, flaw, defect, crack, leak, deformation or broken part."
    ),
    "cashew": (
        "This is a photo of a cashew nut for anomaly detection, which should be whole and intact, "
        "without any damage, flaw, defect, scratch, hole, crack, discoloration or broken part."
    ),
    "chewinggum": (
        "This is a photo of chewing gum for anomaly detection, which should have uniform surface "
        "without any damage, flaw, defect, scratch, hole, crack, contamination or broken part."
    ),
    "fryum": (
        "This is a photo of fryum (snack) for anomaly detection, which should be whole and properly shaped, "
        "without any damage, flaw, defect, scratch, hole, crack, burn mark or broken part."
    ),
    "macaroni1": (
        "This is a photo of macaroni pasta for anomaly detection, which should be properly shaped "
        "without any damage, flaw, defect, scratch, hole, crack, deformation or broken part."
    ),
    "macaroni2": (
        "This is a photo of macaroni pasta for anomaly detection, which should be properly shaped "
        "without any damage, flaw, defect, scratch, hole, crack, deformation or broken part."
    ),
    "pcb1": (
        "This is a photo of a PCB (printed circuit board) for anomaly detection, which should have "
        "proper solder joints and traces without any damage, flaw, defect, scratch, missing component, "
        "cold solder, short circuit or broken part."
    ),
    "pcb2": (
        "This is a photo of a PCB (printed circuit board) for anomaly detection, which should have "
        "proper solder joints and traces without any damage, flaw, defect, scratch, missing component, "
        "cold solder, short circuit or broken part."
    ),
    "pcb3": (
        "This is a photo of a PCB (printed circuit board) for anomaly detection, which should have "
        "proper solder joints and traces without any damage, flaw, defect, scratch, missing component, "
        "cold solder, short circuit or broken part."
    ),
    "pcb4": (
        "This is a photo of a PCB (printed circuit board) for anomaly detection, which should have "
        "proper solder joints and traces without any damage, flaw, defect, scratch, missing component, "
        "cold solder, short circuit or broken part."
    ),
    "pipe_fryum": (
        "This is a photo of pipe-shaped fryum (snack) for anomaly detection, which should be properly shaped "
        "without any damage, flaw, defect, scratch, hole, crack, burn mark or broken part."
    ),
}


USER_PROMPT = (
    "{class_desc} You are an expert industrial inspector. "
    "Please inspect this image strictly and determine whether the object is normal or defective. "
    "Always provide a segmentation mask. If the object is normal, the mask should be empty."
)

# Borrowed and adapted from AnomalyGPT (all_supervised_with_cn.py).
ANOMALY_QUESTIONS_EN: list[str] = [
    "Are there any anomalies in the image?",
    "Are there any defects in the image?",
    "Is there any anomaly in the image?",
    "Do you notice any abnormalities in the image?",
    "Can you identify any aberrations in the image?",
    "Are there any inconsistencies in the image?",
    "Are there any unusual elements in the image?",
    "Do you observe any irregularities in the image?",
]

ANOMALY_QUESTIONS_CN: list[str] = [
    "图像中是否存在任何异常？",
    "图像中是否存在任何缺陷？",
    "你是否注意到图像中的任何异常情况？",
    "你能否识别出图像中的任何异常现象？",
    "图像中是否存在任何不一致之处？",
    "图像中是否存在任何不寻常的元素？",
]

# --- 1. User Prompts (Single Image) ---
USER_PROMPT_TEMPLATES: list[str] = [
    USER_PROMPT,
    # English variants
    "{class_desc} Please perform a strict surface quality inspection. Always output a segmentation mask; if no defect exists, output an empty mask.",
    "{class_desc} Inspect carefully for scratches, dents, contamination, cracks, missing parts, or any other anomaly. Always provide a segmentation mask; use an empty mask when normal.",
    "{class_desc} Industrial quality check: decide whether the object is good or defective. Always output the segmentation mask (empty if good).",
    *[
        f"{{class_desc}} {q} Always provide a segmentation mask; if no anomaly is found, output an empty mask."
        for q in ANOMALY_QUESTIONS_EN
    ],
    # Chinese variants
    "{class_desc} 请进行严格的工业质检，判断该物体是否存在异常/缺陷。请始终输出分割掩码；若不存在异常，则输出空掩码。",
    "{class_desc} 请仔细检查表面是否有划痕、凹陷、污染、裂纹、缺口等异常。请始终给出分割掩码；正常时输出空掩码。",
    *[
        f"{{class_desc}} {q} 请始终输出分割掩码；若无异常，则输出空掩码。"
        for q in ANOMALY_QUESTIONS_CN
    ],
]

USER_PROMPT_FEWSHOT = (
    "{class_desc} The first image is the target to inspect. "
    "The following {k} images are normal reference samples of the same category. "
    "Compare the target with the references strictly. "
    "Always provide a segmentation mask; if the target is normal, the mask should be empty."
)

# --- 2. User Prompts (Few-Shot / In-Context) ---
USER_PROMPT_FEWSHOT_TEMPLATES: list[str] = [
    "{class_desc} The first image is the query image to inspect. The following {k} images are 'Golden Samples' (normal references). Compare the query with the references to spot any deviations. Always output a segmentation mask (empty if normal).",
    "{class_desc} I will show you a target image followed by {k} normal examples. Use the normal examples to understand the standard appearance, then output a segmentation mask for the target (empty if no defect).",
    "{class_desc} Reference images (Normal): The last {k} images. Target image: The first one. Compare strictly and always output a segmentation mask for the target (empty if normal).",
    "{class_desc} Image 1 is the query. Images 2-{k_plus_1} are normal references. Always output the segmentation mask for the query image (empty if normal).",
]

# --- 3. Teacher-Forcing Assistant Stub (single-mask, mask-only) ---
TEACHER_FORCING_ASSISTANT_STUB = "Segmentation mask: <SEG>."
ASSISTANT_MASK_ONLY_TEMPLATES: list[str] = [TEACHER_FORCING_ASSISTANT_STUB]


def sample_user_prompt(rng: random.Random, class_desc: str) -> str:
    # Fixed prompt (no random template sampling): keep training/eval deterministic and consistent.
    # NOTE: `rng` is kept for API compatibility.
    return USER_PROMPT.format(class_desc=class_desc)


def sample_user_prompt_fewshot(rng: random.Random, class_desc: str, k: int) -> str:
    template = rng.choice(USER_PROMPT_FEWSHOT_TEMPLATES)
    k_int = int(k)
    return template.format(
        class_desc=class_desc,
        k=k_int,
        k_plus_1=k_int + 1,
    )


def sample_assistant_normal(rng: random.Random, class_desc: str = "") -> str:
    return TEACHER_FORCING_ASSISTANT_STUB


def sample_assistant_mask_only(rng: random.Random) -> str:
    return TEACHER_FORCING_ASSISTANT_STUB


def sample_assistant_defect(
    rng: random.Random,
    *,
    class_desc: str = "",
    centers: Sequence[tuple[float, float]] | None = None,
    image_hw: tuple[int, int] = (1, 1),
    mask_only: bool = False,
) -> str:
    return TEACHER_FORCING_ASSISTANT_STUB
