import cv2
import numpy as np
import torch
from PIL import Image

from .mvtec_dataset_two_source import MVtecIADDatasetTwoSource
from .mvtec_prompts import (
    sample_assistant_defect,
    sample_assistant_mask_only,
    sample_assistant_normal,
    sample_user_prompt,
)


class MVtecIADTripletDatasetTwoSource(MVtecIADDatasetTwoSource):
    """Triplet training dataset: normal + same-class synthetic + DTD synthetic.

    This aligns with the desired training set composition:
    - N normal images (train/good)
    - N synthetic anomalies using same-class (in-domain) patch source
    - N synthetic anomalies using DTD (out-of-domain texture) patch source

    The anomaly synthesis method itself (PatchEx/Poisson, label_mode, thresholds, etc.) is unchanged.
    Only the patch_source selection and the number of synthetic variants per normal image are changed.
    """

    def __init__(self, *args, **kwargs):
        split = kwargs.get("split", "train")
        if split != "train":
            raise ValueError("MVtecIADTripletDatasetTwoSource only supports split='train'.")
        super().__init__(*args, **kwargs)

        if not getattr(self, "dtd_image_paths", None):
            raise ValueError(
                "DTD image pool is empty. Please set dtd_root to a valid DTD images directory."
            )

    def _patch_rgb_for_same_class(self, *, class_name: str, exclude_path: str, fallback_rgb: np.ndarray) -> np.ndarray:
        for _ in range(16):
            p = self._sample_same_class_path(class_name=class_name, exclude_path=exclude_path)
            if p is None:
                break
            rgb = self._load_patch_rgb(patch_path=p)
            if rgb is not None:
                return rgb
        return fallback_rgb

    def _patch_rgb_for_dtd(self, *, fallback_rgb: np.ndarray) -> np.ndarray:
        for _ in range(16):
            p = self._sample_dtd_path()
            if p is None:
                break
            rgb = self._load_patch_rgb(patch_path=p)
            if rgb is not None:
                return rgb
        return fallback_rgb

    def _build_synthetic_sample(
        self,
        *,
        base_rgb: np.ndarray,
        class_name: str,
        class_desc: str,
        user_text: str,
        patch_rgb: np.ndarray,
        defect_type: str,
    ) -> dict:
        syn_rgb, syn_mask, centers = self.synth(base_rgb, patch_rgb, class_name=class_name)

        thr = 0.0 if self.mask_threshold is None else float(self.mask_threshold)
        syn_has_mask = float(np.max(syn_mask)) > thr

        syn_image_pil = Image.fromarray(syn_rgb)
        syn_image_sam, syn_resize, syn_original_size = self._preprocess_sam(syn_rgb)

        if syn_has_mask:
            syn_gt_mask = torch.from_numpy(syn_mask.astype(np.float32)).unsqueeze(0).float()
            if self.return_assistant:
                assistant_text = (
                    sample_assistant_mask_only(self.rng)
                    if getattr(self, "assistant_mask_only", False)
                    else sample_assistant_defect(
                        self.rng,
                        class_desc=class_desc,
                        centers=centers,
                        image_hw=syn_rgb.shape[:2],
                    )
                )
            else:
                assistant_text = None
            out_defect_type = defect_type
        else:
            syn_gt_mask = torch.zeros((1, syn_original_size[0], syn_original_size[1]), dtype=torch.float32)
            if self.return_assistant:
                assistant_text = (
                    sample_assistant_mask_only(self.rng)
                    if getattr(self, "assistant_mask_only", False)
                    else sample_assistant_normal(self.rng, class_desc=class_desc)
                )
            else:
                assistant_text = None
            out_defect_type = "good"

        syn_messages = self._build_messages_from_text(
            syn_image_pil,
            user_text,
            assistant_text=assistant_text,
        )
        return {
            "class_name": class_name,
            "defect_type": out_defect_type,
            "messages": syn_messages,
            "image_qwen": syn_image_pil,
            "image_sam": syn_image_sam,
            "sam_resize": syn_resize,
            "sam_original_size": syn_original_size,
            "gt_mask": syn_gt_mask,
            "has_mask": syn_has_mask,
            "synthetic": True,
        }

    def __getitem__(self, idx: int):
        base = self.samples[idx]
        image_path = base["image_path"]
        class_name = base["class_name"]

        class_desc = self._get_class_desc(class_name)
        user_text = sample_user_prompt(self.rng, class_desc)

        image_bgr = cv2.imread(image_path)
        if image_bgr is None:
            raise ValueError(f"Failed to read image: {image_path}")
        base_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        base_rgb = self._resize_model_rgb_square(base_rgb)

        # Normal sample (unchanged)
        image_pil = Image.fromarray(base_rgb)
        image_sam, resize, original_size = self._preprocess_sam(base_rgb)
        normal_gt_mask = torch.zeros((1, original_size[0], original_size[1]), dtype=torch.float32)
        if self.return_assistant:
            normal_assistant = (
                sample_assistant_mask_only(self.rng)
                if getattr(self, "assistant_mask_only", False)
                else sample_assistant_normal(self.rng, class_desc=class_desc)
            )
        else:
            normal_assistant = None
        normal_messages = self._build_messages_from_text(
            image_pil,
            user_text,
            assistant_text=normal_assistant,
        )
        normal_sample = {
            "image_path": image_path,
            "class_name": class_name,
            "defect_type": "good",
            "messages": normal_messages,
            "image_qwen": image_pil,
            "image_sam": image_sam,
            "sam_resize": resize,
            "sam_original_size": original_size,
            "gt_mask": normal_gt_mask,
            "has_mask": False,
            "synthetic": False,
        }

        # Synthetic (same-class pool)
        same_patch_rgb = self._patch_rgb_for_same_class(
            class_name=class_name,
            exclude_path=str(image_path),
            fallback_rgb=base_rgb,
        )
        same_patch_rgb = self._resize_model_rgb_square(same_patch_rgb)
        syn_same = self._build_synthetic_sample(
            base_rgb=base_rgb,
            class_name=class_name,
            class_desc=class_desc,
            user_text=user_text,
            patch_rgb=same_patch_rgb,
            defect_type="synthetic_same_class",
        )
        syn_same["image_path"] = image_path

        # Synthetic (DTD pool)
        dtd_patch_rgb = self._patch_rgb_for_dtd(fallback_rgb=base_rgb)
        dtd_patch_rgb = self._resize_model_rgb_square(dtd_patch_rgb)
        syn_dtd = self._build_synthetic_sample(
            base_rgb=base_rgb,
            class_name=class_name,
            class_desc=class_desc,
            user_text=user_text,
            patch_rgb=dtd_patch_rgb,
            defect_type="synthetic_dtd",
        )
        syn_dtd["image_path"] = image_path

        # Keep legacy behavior for determinism compatibility (also used as fallback in base class).
        self.prev_idx = idx
        return {"pair": [normal_sample, syn_same, syn_dtd]}
