import glob
import os
import random
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import Dataset

from segment_anything.utils.transforms import ResizeLongestSide

from .visa_prompts import (
    DESCRIPTIONS_VISA,
    USER_PROMPT,
    sample_assistant_defect,
    sample_assistant_mask_only,
    sample_assistant_normal,
    sample_user_prompt,
)
from .visa_synthesis import PatchExVisaSynthesizer


def _list_images(root_dir: str):
    patterns = ["*.jpg", "*.JPG", "*.jpeg", "*.JPEG", "*.png", "*.PNG"]
    files = []
    for pattern in patterns:
        files.extend(glob.glob(os.path.join(root_dir, pattern)))
    return sorted(files)


class VisaIADDataset(Dataset):
    """VisA dataset for Industrial Anomaly Detection.
    
    VisA dataset structure:
    VisA/
        {class_name}/
            train/
                good/
                    0000.JPG, 0001.JPG, ...
            test/
                good/
                    000.JPG, 001.JPG, ...
                bad/
                    000.JPG, 001.JPG, ...
            ground_truth/
                bad/
                    000.png, 001.png, ...
    """
    pixel_mean = torch.Tensor([123.675, 116.28, 103.53]).view(-1, 1, 1)
    pixel_std = torch.Tensor([58.395, 57.12, 57.375]).view(-1, 1, 1)

    def __init__(
        self,
        root_dir: str,
        split: str = "train",
        categories: list[str] | None = None,
        k_shot: int | None = None,
        anomaly_prob: float = 0.5,
        sam_image_size: int = 1024,
        model_image_size: int = 224,
        mask_threshold: float | None = 0.3,
        seed: int = 0,
        return_assistant: bool = True,
        assistant_mask_only: bool = False,
    ):
        self.root_dir = root_dir
        self.split = split
        self.categories = categories
        self.k_shot = k_shot
        self.anomaly_prob = anomaly_prob
        self.sam_image_size = sam_image_size
        self.model_image_size = int(model_image_size) if model_image_size is not None else None
        self.mask_threshold = mask_threshold
        self.return_assistant = return_assistant
        self.assistant_mask_only = assistant_mask_only

        self.rng = random.Random(seed)
        self.synth = PatchExVisaSynthesizer()
        self.sam_transform = ResizeLongestSide(sam_image_size)

        class_dirs = sorted([d for d in Path(root_dir).iterdir() if d.is_dir()])
        if categories is not None:
            allow = set(categories)
            class_dirs = [d for d in class_dirs if d.name in allow]

        self.samples: list[dict] = []
        if split == "train":
            for class_dir in class_dirs:
                class_name = class_dir.name
                good_dir = class_dir / "train" / "good"
                image_paths = _list_images(str(good_dir))
                if k_shot is not None:
                    self.rng.shuffle(image_paths)
                    image_paths = image_paths[:k_shot]
                for path in image_paths:
                    self.samples.append({"image_path": path, "class_name": class_name})
        elif split == "test":
            for class_dir in class_dirs:
                class_name = class_dir.name
                test_dir = class_dir / "test"
                if not test_dir.exists():
                    continue
                # VisA test structure: test/good and test/bad
                for defect_dir in sorted([d for d in test_dir.iterdir() if d.is_dir()]):
                    defect_type = defect_dir.name
                    for img_path in _list_images(str(defect_dir)):
                        is_good = defect_type == "good"
                        mask_path = None
                        if not is_good:
                            # VisA mask: ground_truth/bad/{stem}.png
                            stem = Path(img_path).stem
                            gt_dir = class_dir / "ground_truth" / defect_type
                            mask_path = str(gt_dir / f"{stem}.png")
                        self.samples.append(
                            {
                                "image_path": img_path,
                                "class_name": class_name,
                                "defect_type": defect_type,
                                "is_good": is_good,
                                "mask_path": mask_path,
                            }
                        )
        else:
            raise ValueError(f"Unknown split: {split}")

        if len(self.samples) == 0:
            raise ValueError(f"No samples found in {root_dir} split={split}")

        self.prev_idx = self.rng.randrange(len(self.samples)) if self.split == "train" else None

    def __len__(self):
        return len(self.samples)

    def _resize_model_rgb_square(self, image_rgb: np.ndarray) -> np.ndarray:
        """Resize model/synthesis input to a fixed square size (AnomalyGPT-style 224×224)."""
        if self.model_image_size is None:
            return image_rgb
        size = int(self.model_image_size)
        if image_rgb.shape[0] == size and image_rgb.shape[1] == size:
            return image_rgb
        return cv2.resize(image_rgb, (size, size), interpolation=cv2.INTER_CUBIC)

    def _resize_short_side_and_center_crop_rgb(self, image_rgb: np.ndarray) -> np.ndarray:
        """Match AnomalyGPT VisA test preprocessing: Resize(short_side=224)+CenterCrop(224)."""
        if self.model_image_size is None:
            return image_rgb
        size = int(self.model_image_size)
        h, w = int(image_rgb.shape[0]), int(image_rgb.shape[1])
        if h <= 0 or w <= 0:
            raise ValueError(f"Invalid image size: {(h, w)}")

        if w < h:
            new_w = size
            new_h = int(size * h / w)
        elif h < w:
            new_h = size
            new_w = int(size * w / h)
        else:
            new_h = size
            new_w = size

        resized = cv2.resize(image_rgb, (new_w, new_h), interpolation=cv2.INTER_LINEAR)

        top = int(round((new_h - size) / 2.0))
        left = int(round((new_w - size) / 2.0))
        top = max(0, min(top, new_h - size))
        left = max(0, min(left, new_w - size))
        return resized[top : top + size, left : left + size]

    def _preprocess_sam(self, image_np: np.ndarray):
        original_size = image_np.shape[:2]
        image_sam = self.sam_transform.apply_image(image_np)
        resize = image_sam.shape[:2]
        image_sam = torch.from_numpy(image_sam).permute(2, 0, 1).contiguous().float()
        image_sam = (image_sam - self.pixel_mean) / self.pixel_std

        h, w = image_sam.shape[-2:]
        pad_h = self.sam_image_size - h
        pad_w = self.sam_image_size - w
        image_sam = F.pad(image_sam, (0, pad_w, 0, pad_h))
        return image_sam, resize, original_size

    def _get_class_desc(self, class_name: str) -> str:
        return DESCRIPTIONS_VISA.get(
            class_name,
            f"This is a photo of {class_name} for anomaly detection. The object should be normal.",
        )

    def _build_messages(self, image_pil: Image.Image, class_name: str, assistant_text: str | None):
        class_desc = self._get_class_desc(class_name)
        user_text = USER_PROMPT.format(class_desc=class_desc)
        return self._build_messages_from_text(image_pil, user_text, assistant_text=assistant_text)

    def _build_messages_from_text(
        self, image_pil: Image.Image, user_text: str, assistant_text: str | None
    ):
        user_msg = {
            "role": "user",
            "content": [
                {"type": "image", "image": image_pil},
                {"type": "text", "text": user_text},
            ],
        }
        if assistant_text is None:
            return [user_msg]
        assistant_msg = {"role": "assistant", "content": [{"type": "text", "text": assistant_text}]}
        return [user_msg, assistant_msg]

    def __getitem__(self, idx: int):
        sample = self.samples[idx]
        image_path = sample["image_path"]
        class_name = sample["class_name"]

        image_bgr = cv2.imread(image_path)
        if image_bgr is None:
            raise ValueError(f"Failed to read image: {image_path}")
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        if self.split == "train":
            image_rgb = self._resize_model_rgb_square(image_rgb)
        else:
            image_rgb = self._resize_short_side_and_center_crop_rgb(image_rgb)

        has_mask = False
        mask = None
        centers = None

        if self.split == "train":
            class_desc = self._get_class_desc(class_name)
            user_text = sample_user_prompt(self.rng, class_desc)

            if self.rng.random() < self.anomaly_prob:
                patch_src = self.samples[self.prev_idx]["image_path"]
                patch_bgr = cv2.imread(patch_src)
                patch_rgb = cv2.cvtColor(patch_bgr, cv2.COLOR_BGR2RGB)
                patch_rgb = self._resize_model_rgb_square(patch_rgb)
                syn, syn_mask, centers = self.synth(image_rgb, patch_rgb, class_name=class_name)

                thr = 0.0 if self.mask_threshold is None else float(self.mask_threshold)
                if float(np.max(syn_mask)) > thr:
                    image_rgb = syn
                    mask = syn_mask.astype(np.float32)
                    has_mask = True
                    if self.return_assistant:
                        if self.assistant_mask_only:
                            assistant_text = sample_assistant_mask_only(self.rng)
                        else:
                            assistant_text = sample_assistant_defect(
                                self.rng,
                                class_desc=class_desc,
                                centers=centers,
                                image_hw=image_rgb.shape[:2],
                            )
                    else:
                        assistant_text = None
                else:
                    if self.return_assistant:
                        assistant_text = (
                            sample_assistant_mask_only(self.rng)
                            if self.assistant_mask_only
                            else sample_assistant_normal(self.rng, class_desc=class_desc)
                        )
                    else:
                        assistant_text = None
            else:
                if self.return_assistant:
                    assistant_text = (
                        sample_assistant_mask_only(self.rng)
                        if self.assistant_mask_only
                        else sample_assistant_normal(self.rng, class_desc=class_desc)
                    )
                else:
                    assistant_text = None

            self.prev_idx = idx
            defect_type = "synthetic" if has_mask else "good"
        else:
            is_good = bool(sample.get("is_good", True))
            defect_type = sample.get("defect_type", "good")
            if not is_good:
                mask_path = sample.get("mask_path")
                if mask_path and os.path.exists(mask_path):
                    gt = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
                    if gt is None:
                        raise ValueError(f"Failed to read mask: {mask_path}")
                    mask = (gt > 0).astype(np.uint8)
                    has_mask = True
            class_desc = self._get_class_desc(class_name)
            user_text = USER_PROMPT.format(class_desc=class_desc)
            if self.return_assistant:
                if self.assistant_mask_only:
                    assistant_text = sample_assistant_mask_only(self.rng)
                elif has_mask:
                    assistant_text = sample_assistant_defect(
                        self.rng, class_desc=class_desc, centers=None, image_hw=image_rgb.shape[:2]
                    )
                else:
                    assistant_text = sample_assistant_normal(self.rng, class_desc=class_desc)
            else:
                assistant_text = None

        image_pil = Image.fromarray(image_rgb)
        image_sam, resize, original_size = self._preprocess_sam(image_rgb)

        if mask is None:
            gt_mask = torch.zeros((1, original_size[0], original_size[1]), dtype=torch.float32)
        else:
            gt_mask = torch.from_numpy(mask).unsqueeze(0).float()

        messages = self._build_messages_from_text(image_pil, user_text, assistant_text=assistant_text)

        return {
            "image_path": image_path,
            "class_name": class_name,
            "defect_type": defect_type,
            "messages": messages,
            "image_qwen": image_pil,
            "image_sam": image_sam,
            "sam_resize": resize,
            "sam_original_size": original_size,
            "gt_mask": gt_mask,
            "has_mask": has_mask,
        }
