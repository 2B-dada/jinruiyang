import torch


class Qwen3VLCollator:
    def __init__(self, processor, training=True):
        self.processor = processor
        self.training = training

    def __call__(self, batch):
        messages = [item["messages"] for item in batch]

        inputs = self.processor.apply_chat_template(
            messages,
            tokenize=True,
            add_generation_prompt=not self.training,
            return_dict=True,
            return_tensors="pt",
            padding=True,
        )

        labels = None
        if self.training:
            labels = inputs["input_ids"].clone()
            for i, msg in enumerate(messages):
                user_only = [msg[0]]
                prompt_inputs = self.processor.apply_chat_template(
                    user_only,
                    tokenize=True,
                    add_generation_prompt=True,
                    return_dict=True,
                    return_tensors="pt",
                )
                prompt_len = prompt_inputs["input_ids"].shape[1]
                labels[i, :prompt_len] = -100
            labels[inputs["attention_mask"] == 0] = -100

        sam_images = torch.stack([item["image_sam"] for item in batch], dim=0)
        sam_resize = [item["sam_resize"] for item in batch]
        sam_original_size = [item["sam_original_size"] for item in batch]
        gt_masks = [item["gt_mask"] for item in batch]
        has_mask = torch.tensor([item["has_mask"] for item in batch], dtype=torch.bool)

        return {
            "input_ids": inputs["input_ids"],
            "attention_mask": inputs["attention_mask"],
            "pixel_values": inputs.get("pixel_values"),
            "image_grid_thw": inputs.get("image_grid_thw"),
            "labels": labels,
            "sam_images": sam_images,
            "sam_resize": sam_resize,
            "sam_original_size": sam_original_size,
            "gt_masks": gt_masks,
            "has_mask": has_mask,
            "image_paths": [item["image_path"] for item in batch],
            "class_names": [item["class_name"] for item in batch],
        }
