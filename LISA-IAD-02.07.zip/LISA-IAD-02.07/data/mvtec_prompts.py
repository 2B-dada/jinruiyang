from __future__ import annotations

import random
from typing import Iterable, Sequence

MVTEC_CLASSES = [
    "bottle",
    "cable",
    "capsule",
    "carpet",
    "grid",
    "hazelnut",
    "leather",
    "metal_nut",
    "pill",
    "screw",
    "tile",
    "toothbrush",
    "transistor",
    "wood",
    "zipper",
]


# Ported from AnomalyGPT (code/datasets/mvtec.py: describles)
DESCRIPTIONS_MVTEC = {
    "bottle": (
        "This is a photo of a bottle for anomaly detection, which should be round, without any "
        "damage, flaw, defect, scratch, hole or broken part."
    ),
    "cable": (
        "This is a photo of three cables for anomaly detection, they are green, blue and grey, "
        "which cannot be missed or swapped and should be without any damage, flaw, defect, scratch, "
        "hole or broken part."
    ),
    "capsule": (
        "This is a photo of a capsule for anomaly detection, which should be black and orange, with "
        "print '500', without any damage, flaw, defect, scratch, hole or broken part."
    ),
    "carpet": (
        "This is a photo of carpet for anomaly detection, which should be without any damage, flaw, "
        "defect, scratch, hole or broken part."
    ),
    "grid": (
        "This is a photo of grid for anomaly detection, which should be without any damage, flaw, "
        "defect, scratch, hole or broken part."
    ),
    "hazelnut": (
        "This is a photo of a hazelnut for anomaly detection, which should be without any damage, "
        "flaw, defect, scratch, hole or broken part."
    ),
    "leather": (
        "This is a photo of leather for anomaly detection, which should be brown and without any "
        "damage, flaw, defect, scratch, hole or broken part."
    ),
    "metal_nut": (
        "This is a photo of a metal nut for anomaly detection, which should be without any damage, "
        "flaw, defect, scratch, hole or broken part, and shouldn't be fliped."
    ),
    "pill": (
        "This is a photo of a pill for anomaly detection, which should be white, with print 'FF' and "
        "red patterns, without any damage, flaw, defect, scratch, hole or broken part."
    ),
    "screw": (
        "This is a photo of a screw for anomaly detection, which tail should be sharp, and without "
        "any damage, flaw, defect, scratch, hole or broken part."
    ),
    "tile": (
        "This is a photo of tile for anomaly detection, which should be without any damage, flaw, "
        "defect, scratch, hole or broken part."
    ),
    "toothbrush": (
        "This is a photo of a toothbrush for anomaly detection, which should be without any damage, "
        "flaw, defect, scratch, hole or broken part."
    ),
    "transistor": (
        "This is a photo of a transistor for anomaly detection, which should be without any damage, "
        "flaw, defect, scratch, hole or broken part."
    ),
    "wood": (
        "This is a photo of wood for anomaly detection, which should be brown with patterns, without "
        "any damage, flaw, defect, scratch, hole or broken part."
    ),
    "zipper": (
        "This is a photo of a zipper for anomaly detection, which should be without any damage, flaw, "
        "defect, scratch, hole or broken part."
    ),
}


USER_PROMPT = (
    "{class_desc} You are an expert industrial inspector. "
    "Please inspect this image strictly and determine whether the object is normal or defective. "
    "Always provide a segmentation mask. If the object is normal, the mask should be empty."
)

# Borrowed and adapted from AnomalyGPT (all_supervised_with_cn.py).
ANOMALY_QUESTIONS_EN: list[str] = [
    "Are there any anomalies in the image?",
    "Are there any defects in the image?",
    "Is there any anomaly in the image?",
    "Do you notice any abnormalities in the image?",
    "Can you identify any aberrations in the image?",
    "Are there any inconsistencies in the image?",
    "Are there any unusual elements in the image?",
    "Do you observe any irregularities in the image?",
]

ANOMALY_QUESTIONS_CN: list[str] = [
    "图像中是否存在任何异常？",
    "图像中是否存在任何缺陷？",
    "你是否注意到图像中的任何异常情况？",
    "你能否识别出图像中的任何异常现象？",
    "图像中是否存在任何不一致之处？",
    "图像中是否存在任何不寻常的元素？",
]

# --- 1. User Prompts (Single Image) ---
# 注意：用户侧 prompt 不应包含字面量的特殊分割 token（避免提取到错误的 embedding）。
USER_PROMPT_TEMPLATES: list[str] = [
    USER_PROMPT,
    # English variants
    "{class_desc} Please perform a strict surface quality inspection. Always output a segmentation mask; if no defect exists, output an empty mask.",
    "{class_desc} Inspect carefully for scratches, dents, contamination, cracks, missing parts, or any other anomaly. Always provide a segmentation mask; use an empty mask when normal.",
    "{class_desc} Industrial quality check: decide whether the object is good or defective. Always output the segmentation mask (empty if good).",
    *[
        f"{{class_desc}} {q} Always provide a segmentation mask; if no anomaly is found, output an empty mask."
        for q in ANOMALY_QUESTIONS_EN
    ],
    # Chinese variants
    "{class_desc} 请进行严格的工业质检，判断该物体是否存在异常/缺陷。请始终输出分割掩码；若不存在异常，则输出空掩码。",
    "{class_desc} 请仔细检查表面是否有划痕、凹陷、污染、裂纹、缺口等异常。请始终给出分割掩码；正常时输出空掩码。",
    *[
        f"{{class_desc}} {q} 请始终输出分割掩码；若无异常，则输出空掩码。"
        for q in ANOMALY_QUESTIONS_CN
    ],
]

USER_PROMPT_FEWSHOT = (
    "{class_desc} The first image is the target to inspect. "
    "The following {k} images are normal reference samples of the same category. "
    "Compare the target with the references strictly. "
    "Always provide a segmentation mask; if the target is normal, the mask should be empty."
)

# --- 2. User Prompts (Few-Shot / In-Context) ---
# 优化点：明确“参考图”是标准，要求模型进行“对比”而非独立看图
USER_PROMPT_FEWSHOT_TEMPLATES: list[str] = [
    # 标准定义模式
    "{class_desc} The first image is the query image to inspect. The following {k} images are 'Golden Samples' (normal references). Compare the query with the references to spot any deviations. Always output a segmentation mask (empty if normal).",
    # 找不同模式
    "{class_desc} I will show you a target image followed by {k} normal examples. Use the normal examples to understand the standard appearance, then output a segmentation mask for the target (empty if no defect).",
    # 严格对比模式
    "{class_desc} Reference images (Normal): The last {k} images. Target image: The first one. Compare strictly and always output a segmentation mask for the target (empty if normal).",
    # 简明模式
    "{class_desc} Image 1 is the query. Images 2-{k_plus_1} are normal references. Always output the segmentation mask for the query image (empty if normal).",
]

# --- 3. Teacher-Forcing Assistant Stub (single-mask, mask-only) ---
# In our teacher-forcing workflow, we always append (or include) exactly one <SEG> token
# in the assistant response and extract its last-layer hidden embedding as the mask prompt.
#
# To keep training/evaluation/inference consistent and deterministic, we use a single fixed stub.
TEACHER_FORCING_ASSISTANT_STUB = "Segmentation mask: <SEG>."

# The following list is kept for compatibility, but in teacher-forcing mask-only mode we always
# return TEACHER_FORCING_ASSISTANT_STUB (see sample_assistant_mask_only()).
ASSISTANT_MASK_ONLY_TEMPLATES: list[str] = [TEACHER_FORCING_ASSISTANT_STUB]

# NOTE: The rich assistant response templates (defect/normal wording, positions, Chinese variants, etc.)
# are currently unused in the teacher-forcing + mask-only setup. We keep them here as a disabled block
# for reference, in case you later switch to assistant_mask_only=False or generation-based prompting.
if False:  # pragma: no cover
    ASSISTANT_DEFECT = (
        "Defect detected. I found an anomaly on the object surface. Here is the segmentation mask: <SEG>."
    )

    ASSISTANT_MASK_ONLY_TEMPLATES_LEGACY: list[str] = [
        "Segmentation: <SEG>.",
        "Segmentation mask: <SEG>.",
        "Mask: <SEG>.",
        "输出：<SEG>。",
        "分割结果：<SEG>。",
        "分割掩码：<SEG>。",
    ]

    ASSISTANT_DEFECT_TEMPLATES: list[str] = [
        "Defect detected. I found an anomaly on the object surface. Here is the segmentation mask: <SEG>.",
        "Yes, the object is defective. There is a visible irregularity{pos_clause}. Segmentation: <SEG>.",
        "I have identified a damaged area{pos_clause}. The surface pattern is interrupted. Mask: <SEG>.",
        "An anomaly is present{pos_clause}. It looks like contamination or a scratch. <SEG>.",
        "Attention required. A manufacturing flaw was found{pos_clause}. <SEG>.",
        "Defect found{pos_clause}. <SEG>.",
        "Quality check failed. I spotted an imperfection{pos_clause}. Here is the region: <SEG>.",
        "是的，图像中存在异常{pos_clause_cn}。分割掩码如下：<SEG>。",
        "检测到缺陷{pos_clause_cn}。请查看分割结果：<SEG>。",
    ]

    ASSISTANT_NORMAL = "No defect detected. The object is normal. Segmentation mask (empty): <SEG>."
    ASSISTANT_NORMAL_TEMPLATES: list[str] = [
        "No, there is no anomaly in the image. Segmentation mask (empty): <SEG>.",
        "No, there is no defect in the image. Segmentation mask (empty): <SEG>.",
        "No anomalies detected. The object is normal. Mask: <SEG>.",
        "No defect detected. The object is normal. Mask: <SEG>.",
        "I inspected the image strictly and found no manufacturing defects. Empty mask: <SEG>.",
        "Pass. The surface is clean and defect-free. Empty mask: <SEG>.",
        "不，图像中没有任何异常。空掩码如下：<SEG>。",
        "不，图像中没有任何缺陷。空掩码如下：<SEG>。",
        "未发现异常，物体正常。空掩码：<SEG>。",
        "质检通过：未发现缺陷。空掩码：<SEG>。",
    ]

    CHINESE_POSITION = {
        "top": "上方",
        "top left": "左上方",
        "top right": "右上方",
        "bottom": "下方",
        "bottom left": "左下方",
        "bottom right": "右下方",
        "center": "中间",
        "left": "左侧",
        "right": "右侧",
    }

    def _join_positions(positions: Sequence[str]) -> str:
        ...

    def _join_positions_cn(positions: Sequence[str]) -> str:
        ...

    def centers_to_positions(centers: Iterable[tuple[float, float]], image_hw: tuple[int, int]) -> list[str]:
        ...

    def build_pos_clause(centers: Sequence[tuple[float, float]] | None, image_hw: tuple[int, int]) -> tuple[str, int]:
        ...

    def build_pos_clause_cn(centers: Sequence[tuple[float, float]] | None, image_hw: tuple[int, int]) -> str:
        ...


def sample_user_prompt(rng: random.Random, class_desc: str) -> str:
    # Fixed prompt (no random template sampling): keep training/eval deterministic and consistent.
    # NOTE: `rng` is kept for API compatibility.
    return USER_PROMPT.format(class_desc=class_desc)


def sample_user_prompt_fewshot(rng: random.Random, class_desc: str, k: int) -> str:
    template = rng.choice(USER_PROMPT_FEWSHOT_TEMPLATES)
    k_int = int(k)
    return template.format(
        class_desc=class_desc,
        k=k_int,
        k_plus_1=k_int + 1,
    )


def sample_assistant_normal(rng: random.Random, class_desc: str = "") -> str:
    # Teacher-forcing mask-only: always use a fixed stub for determinism.
    return TEACHER_FORCING_ASSISTANT_STUB


def sample_assistant_mask_only(rng: random.Random) -> str:
    # Teacher-forcing mask-only: always use a fixed stub for determinism.
    return TEACHER_FORCING_ASSISTANT_STUB


def sample_assistant_defect(
    rng: random.Random,
    *,
    class_desc: str = "",
    centers: Sequence[tuple[float, float]] | None = None,
    image_hw: tuple[int, int] = (1, 1),
    mask_only: bool = False,
) -> str:
    # Teacher-forcing mask-only: always use a fixed stub for determinism.
    return TEACHER_FORCING_ASSISTANT_STUB
