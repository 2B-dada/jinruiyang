"""VisA dataset with two patch source routes for anomaly synthesis.

This mirrors `mvtec_dataset_two_source.py` to keep the training pipeline identical
across datasets (only the dataset directory structure differs).
"""

from __future__ import annotations

import glob
import os

import cv2
import numpy as np
import torch
from PIL import Image

from .visa_dataset import VisaIADDataset
from .visa_prompts import (
    sample_assistant_defect,
    sample_assistant_mask_only,
    sample_assistant_normal,
    sample_user_prompt,
)


def _list_images_recursive(root_dir: str) -> list[str]:
    patterns = ["*.jpg", "*.JPG", "*.jpeg", "*.JPEG", "*.png", "*.PNG"]
    files: list[str] = []
    for pattern in patterns:
        files.extend(glob.glob(os.path.join(root_dir, "**", pattern), recursive=True))
    return sorted(files)


class VisaIADDatasetTwoSource(VisaIADDataset):
    """VisA dataset with two patch source routes for anomaly synthesis.

    Routes (used only when split='train' and anomaly synthesis is enabled):
    - same_class: sample patch source from the same VisA category (train/good pool)
    - dtd: sample patch source from external DTD texture dataset
    """

    def __init__(
        self,
        *args,
        patch_source_strategy: str = "mixed",
        dtd_root: str | None = None,
        dtd_prob: float = 0.5,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.patch_source_strategy = str(patch_source_strategy)
        self.dtd_root = str(dtd_root) if dtd_root else None
        self.dtd_prob = float(dtd_prob)

        self.train_good_by_class: dict[str, list[str]] = {}
        self.dtd_image_paths: list[str] = []

        if self.split == "train":
            for s in getattr(self, "samples", []):
                cname = s.get("class_name")
                p = s.get("image_path")
                if cname and p:
                    self.train_good_by_class.setdefault(str(cname), []).append(str(p))

            if self.dtd_root is not None:
                self.dtd_image_paths = _list_images_recursive(self.dtd_root)
                if len(self.dtd_image_paths) == 0:
                    raise ValueError(f"No DTD images found under: {self.dtd_root}")

        if self.patch_source_strategy not in {"mixed", "same_class", "dtd", "prev"}:
            raise ValueError(
                "patch_source_strategy must be one of: mixed, same_class, dtd, prev; "
                f"got: {self.patch_source_strategy}"
            )
        if not (0.0 <= self.dtd_prob <= 1.0):
            raise ValueError(f"dtd_prob must be in [0,1], got: {self.dtd_prob}")
        if self.patch_source_strategy in {"mixed", "dtd"} and self.split == "train" and self.dtd_root is None:
            raise ValueError("dtd_root must be provided when patch_source_strategy uses DTD.")

    def _sample_same_class_path(self, *, class_name: str, exclude_path: str | None) -> str | None:
        pool = self.train_good_by_class.get(str(class_name), [])
        if not pool:
            return None
        if exclude_path is None or len(pool) == 1:
            return self.rng.choice(pool)
        for _ in range(8):
            p = self.rng.choice(pool)
            if p != exclude_path:
                return p
        return self.rng.choice(pool)

    def _sample_dtd_path(self) -> str | None:
        if not self.dtd_image_paths:
            return None
        return self.rng.choice(self.dtd_image_paths)

    def _sample_prev_path(self) -> str | None:
        if getattr(self, "prev_idx", None) is None:
            return None
        try:
            return str(self.samples[int(self.prev_idx)]["image_path"])
        except Exception:
            return None

    def _choose_patch_source_path(self, *, class_name: str, exclude_path: str | None) -> str | None:
        strat = self.patch_source_strategy

        if strat == "same_class":
            return (
                self._sample_same_class_path(class_name=class_name, exclude_path=exclude_path)
                or self._sample_dtd_path()
                or self._sample_prev_path()
            )
        if strat == "dtd":
            return (
                self._sample_dtd_path()
                or self._sample_same_class_path(class_name=class_name, exclude_path=exclude_path)
                or self._sample_prev_path()
            )
        if strat == "prev":
            return (
                self._sample_prev_path()
                or self._sample_same_class_path(class_name=class_name, exclude_path=exclude_path)
                or self._sample_dtd_path()
            )

        use_dtd = self.rng.random() < float(self.dtd_prob)
        if use_dtd:
            return (
                self._sample_dtd_path()
                or self._sample_same_class_path(class_name=class_name, exclude_path=exclude_path)
                or self._sample_prev_path()
            )
        return (
            self._sample_same_class_path(class_name=class_name, exclude_path=exclude_path)
            or self._sample_dtd_path()
            or self._sample_prev_path()
        )

    def _load_patch_rgb(self, *, patch_path: str) -> np.ndarray | None:
        bgr = cv2.imread(patch_path, cv2.IMREAD_COLOR)
        if bgr is None:
            return None
        return cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)

    def sample_patch_source_rgb(
        self, *, class_name: str, exclude_path: str | None, fallback_rgb: np.ndarray
    ) -> np.ndarray:
        for _ in range(16):
            p = self._choose_patch_source_path(class_name=class_name, exclude_path=exclude_path)
            if p is None:
                break
            rgb = self._load_patch_rgb(patch_path=p)
            if rgb is not None:
                return rgb
        return fallback_rgb

    def __getitem__(self, idx: int):
        if self.split != "train":
            return super().__getitem__(idx)

        sample = self.samples[idx]
        image_path = sample["image_path"]
        class_name = sample["class_name"]

        image_bgr = cv2.imread(image_path)
        if image_bgr is None:
            raise ValueError(f"Failed to read image: {image_path}")
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        image_rgb = self._resize_model_rgb_square(image_rgb)

        has_mask = False
        mask = None
        centers = None

        class_desc = self._get_class_desc(class_name)
        user_text = sample_user_prompt(self.rng, class_desc)

        if self.rng.random() < self.anomaly_prob:
            patch_rgb = self.sample_patch_source_rgb(
                class_name=class_name,
                exclude_path=str(image_path),
                fallback_rgb=image_rgb,
            )
            patch_rgb = self._resize_model_rgb_square(patch_rgb)
            syn, syn_mask, centers = self.synth(image_rgb, patch_rgb, class_name=class_name)

            thr = 0.0 if self.mask_threshold is None else float(self.mask_threshold)
            if float(np.max(syn_mask)) > thr:
                image_rgb = syn
                mask = syn_mask.astype(np.float32)
                has_mask = True
                if self.return_assistant:
                    if self.assistant_mask_only:
                        assistant_text = sample_assistant_mask_only(self.rng)
                    else:
                        assistant_text = sample_assistant_defect(
                            self.rng,
                            class_desc=class_desc,
                            centers=centers,
                            image_hw=image_rgb.shape[:2],
                        )
                else:
                    assistant_text = None
            else:
                if self.return_assistant:
                    assistant_text = (
                        sample_assistant_mask_only(self.rng)
                        if self.assistant_mask_only
                        else sample_assistant_normal(self.rng, class_desc=class_desc)
                    )
                else:
                    assistant_text = None
        else:
            if self.return_assistant:
                assistant_text = (
                    sample_assistant_mask_only(self.rng)
                    if self.assistant_mask_only
                    else sample_assistant_normal(self.rng, class_desc=class_desc)
                )
            else:
                assistant_text = None

        self.prev_idx = idx
        defect_type = "synthetic" if has_mask else "good"

        image_pil = Image.fromarray(image_rgb)
        image_sam, resize, original_size = self._preprocess_sam(image_rgb)

        if mask is None:
            gt_mask = torch.zeros((1, original_size[0], original_size[1]), dtype=torch.float32)
        else:
            gt_mask = torch.from_numpy(mask).unsqueeze(0).float()

        messages = self._build_messages_from_text(image_pil, user_text, assistant_text=assistant_text)

        return {
            "image_path": image_path,
            "class_name": class_name,
            "defect_type": defect_type,
            "messages": messages,
            "image_qwen": image_pil,
            "image_sam": image_sam,
            "sam_resize": resize,
            "sam_original_size": original_size,
            "gt_mask": gt_mask,
            "has_mask": has_mask,
        }
