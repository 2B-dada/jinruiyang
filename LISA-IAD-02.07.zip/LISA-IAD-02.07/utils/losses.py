import torch
import torch.nn.functional as F


def dice_loss(inputs: torch.Tensor, targets: torch.Tensor, eps: float = 1e-5) -> torch.Tensor:
    """Compute DICE loss on logits."""
    probs = inputs.sigmoid()
    probs = probs.flatten(1)
    targets = targets.flatten(1)
    numerator = 2.0 * (probs * targets).sum(-1)
    denominator = probs.sum(-1) + targets.sum(-1)
    loss = 1.0 - (numerator + eps) / (denominator + eps)
    return loss.mean()


def sigmoid_focal_loss(
    inputs: torch.Tensor,
    targets: torch.Tensor,
    alpha: float = 0.25,
    gamma: float = 2.0,
    reduction: str = "mean",
) -> torch.Tensor:
    """Focal loss on logits, compatible with dense masks."""
    prob = inputs.sigmoid()
    ce_loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction="none")
    p_t = prob * targets + (1 - prob) * (1 - targets)
    loss = ce_loss * ((1 - p_t) ** gamma)
    if alpha >= 0:
        alpha_t = alpha * targets + (1 - alpha) * (1 - targets)
        loss = alpha_t * loss

    if reduction == "mean":
        return loss.mean()
    if reduction == "sum":
        return loss.sum()
    return loss
