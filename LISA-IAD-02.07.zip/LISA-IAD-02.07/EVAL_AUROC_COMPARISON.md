# Mean i_AUROC / Mean p_AUROC 计算方式对齐说明（LISA-IAD vs AnomalyGPT）

本文档回答三个问题：

1) 目前 `LISA-IAD` 项目里 **Mean i_AUROC** 与 **Mean p_AUROC** 是如何计算的？  
2) AnomalyGPT 源项目里 **Mean i_AUROC** 与 **Mean p_AUROC** 是如何计算的？  
3) 两者是否“完全相同”？如果存在差异，差异点在哪里、会不会影响数值？

---

## 术语与目标

- **i_AUROC / Image-AUROC（图像级 AUROC）**  
  用一个“每张图一个分数”来做二分类（正常 vs 异常）的 ROC-AUC。

- **p_AUROC / Pixel-AUROC（像素级 AUROC）**  
  用“每个像素一个分数”来做二分类（正常像素 vs 异常像素）的 ROC-AUC。通常会把同一类别下所有测试图的像素全部展平拼接后一起算 AUC（per-class、micro over pixels）。

- **Mean i_AUROC / Mean p_AUROC**  
  对每个类别分别计算 i_AUROC / p_AUROC，然后对所有类别 **做简单算术平均**（每个类别权重相同，不按类别样本数加权）。

AnomalyGPT 论文在实验部分说明使用 **image-level AUC** 与 **pixel-level AUC**（以及 accuracy）作为评估指标，并将输入分辨率设为 **224×224**（见 `AnomalyGPT_paper_extracted.txt:498` 与 `AnomalyGPT_paper_extracted.txt:511`）。  
但“图像级分数如何从 anomaly map 得到”的细节主要体现在官方代码实现中（见后文）。

---

## 我们的评估代码（LISA-IAD）如何计算 i_AUROC / p_AUROC / Mean？

### 代码位置

- MVTec：`LISA-IAD/eval/AnomalyGPT_eval_mvtec.py`  
- VisA：`LISA-IAD/eval/AnomalyGPT_eval_visa.py`  
- AUROC 函数（替代 sklearn）：`LISA-IAD/utils/AnomalyGPT_metrics.py`

### per-class 评估流程（核心）

我们按类别计算（per-class），再做 mean。核心流程如下（MVTec/VisA 两个 eval 脚本同构）：

1) **按类别聚合 test 样本**  
   - 从 `dataset.samples` 里读取 `class_name`，构造 `indices_by_class`（每类一个 index 列表）。

2) 对某个类别 `cname`，遍历该类别的所有 test 样本：

   2.1 **得到预测 anomaly map（概率图）**  
   - `pred_prob`：shape `(H,W)`，范围约 `[0,1]`（我们对 SAM 输出 logits 做了 `sigmoid`）。  
   - 该张图的预测会被 resize 到统一评估分辨率 `eval_size`（默认 224）。

   2.2 **得到 GT mask 并二值化**  
   - `gt_mask = sample["gt_mask"][0]`：shape `(H,W)`，由数据集代码提供（测试集 good 图为全零，defect 图为 0/1 mask）。  
   - **MVTec 协议（与 AnomalyGPT/test_mvtec.py 一致）**：  
     - 将 `pred_prob` 与 `gt_mask` 统一 resize 到 `eval_size×eval_size`（默认 224×224）。  
     - `gt_bin = (gt_224 > 0.1)`（见 `LISA-IAD/eval/AnomalyGPT_eval_mvtec.py:347`）。
   - **VisA 协议（与 AnomalyGPT/test_visa.py 一致）**：  
     - 先做 `Resize(short_side=eval_size) + CenterCrop(eval_size)`（见 `LISA-IAD/eval/AnomalyGPT_eval_visa.py:116` 与 `AnomalyGPT/code/test_visa.py:108`）。  
     - 动态阈值二值化：`thr = max(mask) / 100`，再做 `gt_bin = (gt_224 > thr)`（见 `LISA-IAD/eval/AnomalyGPT_eval_visa.py:395` 与 `AnomalyGPT/code/test_visa.py:161` 附近逻辑）。

   2.3 **像素级缓存（用于 p_AUROC）**  
   - 将该图的 `pred_224` 与 `gt_bin` 展平后加入列表（见 `LISA-IAD/eval/AnomalyGPT_eval_mvtec.py:349`）。

   2.4 **图像级缓存（用于 i_AUROC）**  
   - **image score = max anomaly score**：`score = pred_224.max()`（见 `LISA-IAD/eval/AnomalyGPT_eval_mvtec.py:351`）。  
   - **image label**：`label = 1 if has_mask else 0`（由数据集字段 `has_mask` 决定）。

3) 该类别的 AUROC 计算：

   3.1 **p_AUROC（像素级）**  
   - 把该类别所有图的像素展平后拼接：  
     `P = concat(pred_224.reshape(-1))`，`Y = concat(gt_bin.reshape(-1))`  
   - `p_auc = roc_auc_score(Y, P)`（见 `LISA-IAD/eval/AnomalyGPT_eval_mvtec.py:359`）。

   3.2 **i_AUROC（图像级）**  
   - `i_auc = roc_auc_score(image_label, image_pred)`（见 `LISA-IAD/eval/AnomalyGPT_eval_mvtec.py:360`）。

   3.3 **输出为百分比 + 两位小数**  
   - `p_auroc = round(p_auc * 100, 2)`  
   - `i_auroc = round(i_auc * 100, 2)`  
   并把每类的结果加入列表，用于最后求 mean。

4) **Mean i_AUROC / Mean p_AUROC（跨类别平均）**

- `mean_i = mean(i_auc_list)`（见 `LISA-IAD/eval/AnomalyGPT_eval_mvtec.py:375`）  
- `mean_p = mean(p_auc_list)`  

这里的 mean 是 **对 per-class AUROC（百分比）做简单平均**，每个类别权重相同。

### 我们的 `roc_auc_score` 是否等价于 sklearn？

AnomalyGPT 原代码直接用 `sklearn.metrics.roc_auc_score`。我们为了去掉 sklearn 依赖，使用了一个二分类 AUROC 的 rank-based 实现：

- `LISA-IAD/utils/AnomalyGPT_metrics.py:33`：  
  - 使用 **Mann–Whitney U / rank statistics** 形式计算 AUROC  
  - ties 采用 **average rank**（`LISA-IAD/utils/AnomalyGPT_metrics.py:6`）  
  - 当 `y_true` 只有单一类别（全 0 或全 1）时抛出 `ValueError`（`LISA-IAD/utils/AnomalyGPT_metrics.py:50`），与 sklearn 的行为一致

因此在相同 `(y_true, y_score)` 下，两者应给出相同 AUROC（二分类情形）。

---

## AnomalyGPT 源项目的评估代码如何计算 i_AUROC / p_AUROC / Mean？

### 代码位置（官方实现）

- MVTec：`AnomalyGPT/code/test_mvtec.py`  
- VisA：`AnomalyGPT/code/test_visa.py`

两者的 AUROC 计算框架一致：**per-class 计算，然后对类别求 mean**。

### per-class（以 MVTec 为例）

在 `AnomalyGPT/code/test_mvtec.py` 中，对每个类别 `c_name`：

1) 遍历该类别所有 test 图片，得到模型输出 `anomaly_map`，并 reshape 到 `224×224`。

2) 构造 GT mask：
   - good 图：全零 mask  
   - defect 图：读取 `ground_truth/.../*_mask.png`  
   - 预处理：`Resize((224,224)) + ToTensor()`  
   - 二值化：`img_mask > 0.1 => 1 else 0`

3) 缓存用于 AUC：
   - p_AUROC：`p_pred.append(anomaly_map)` / `p_label.append(img_mask)`（见 `AnomalyGPT/code/test_mvtec.py:148`）  
   - i_AUROC：`i_pred.append(anomaly_map.max())` / `i_label.append(1 if defect else 0)`（见 `AnomalyGPT/code/test_mvtec.py:151`）

4) AUROC：
   - `p_auroc = round(roc_auc_score(p_label.ravel(), p_pred.ravel()) * 100, 2)`（见 `AnomalyGPT/code/test_mvtec.py:170`）  
   - `i_auroc = round(roc_auc_score(i_label.ravel(), i_pred.ravel()) * 100, 2)`（见 `AnomalyGPT/code/test_mvtec.py:171`）

5) Mean across classes：
   - `torch.tensor(i_auc_list).mean()` / `torch.tensor(p_auc_list).mean()`

### VisA 的一个细节差异（AnomalyGPT 原 repo 内部）

在 `AnomalyGPT/code/test_visa.py` 中，AUROC 的计算方式与 MVTec 相同，但 **GT mask 的空间预处理**不同：

- `Resize(224) + CenterCrop(224)`（见 `AnomalyGPT/code/test_visa.py:108`）  
- mask 阈值是动态的：`threshold = img_mask.max() / 100`，再做 `img_mask > threshold`

---

## 对齐结论：我们与 AnomalyGPT 是否“完全相同”？

### 1) 指标定义与聚合方式：一致

两边都满足：

- i_AUROC：**image score = anomaly_map.max()**，按图二分类算 ROC-AUC  
- p_AUROC：把该类别所有图的像素全部展平拼接后算 ROC-AUC  
- Mean i/p：对类别做简单平均（每类同权）

### 2) AUROC 函数：等价

- AnomalyGPT：`sklearn.metrics.roc_auc_score`  
- LISA-IAD：`LISA-IAD/utils/AnomalyGPT_metrics.py` 的二分类 rank-based AUROC（tie 平均秩），理论上与 sklearn 二分类一致

### 3) 预处理细节：MVTec / VisA 均已对齐到 AnomalyGPT 原 repo

- **MVTec：**使用 `eval_size×eval_size` 的 resize，并用 `gt>0.1` 二值化（与 `AnomalyGPT/code/test_mvtec.py` 一致）。  
- **VisA：**使用 `Resize(short_side=eval_size) + CenterCrop(eval_size)`，并用 `thr=max(mask)/100` 做动态二值化（与 `AnomalyGPT/code/test_visa.py` 一致）。

---

## 快速总结

- **Mean i_AUROC / Mean p_AUROC 的“计算方式”（max 作为 image score、flatten 像素、per-class 再 mean）**：我们与 AnomalyGPT 官方代码一致。  
- **MVTec/VisA 的 224×224 预处理协议**：现已分别对齐 `AnomalyGPT/code/test_mvtec.py` 与 `AnomalyGPT/code/test_visa.py` 的实现细节。
