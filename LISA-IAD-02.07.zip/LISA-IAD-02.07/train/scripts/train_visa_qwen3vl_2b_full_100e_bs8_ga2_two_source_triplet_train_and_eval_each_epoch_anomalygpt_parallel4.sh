#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"

export PYTHONUNBUFFERED=1
export TOKENIZERS_PARALLELISM=false

# Detect whether MODEL_PATH was explicitly provided by the caller.
MODEL_PATH_PRESET=0
if [[ -n "${MODEL_PATH:-}" ]]; then
  MODEL_PATH_PRESET=1
fi

# Path defaults (DATA_ROOT / MODEL_PATH / SAM_CKPT / MVTEC_ROOT / VISA_ROOT / DTD_ROOT)
# Edit `train/scripts/env.sh` once to adapt paths on a new machine.
source "${SCRIPT_DIR}/env.sh"

# Script-specific default model path (only when caller didn't export MODEL_PATH).
if [[ "${MODEL_PATH_PRESET}" == "0" ]]; then
  MODEL_PATH="${DATA_ROOT}/Qwen/Qwen3-VL-2B-Instruct"
fi

DATASET="${DATASET:-visa}"

# Full training by default (all classes): leave empty to use all.
CATEGORIES="${CATEGORIES:-}"
K_SHOT="${K_SHOT:-}"
PAIRED="${PAIRED:-1}"
ANOMALY_PROB="${ANOMALY_PROB:-1.0}"

# ----------------------------
# Requested defaults (Qwen3-VL-2B, VisA)
# ----------------------------
EPOCHS="${EPOCHS:-100}"
LR="${LR:-7e-5}"
SAM_LR="${SAM_LR:-3e-4}"

LORA_R="${LORA_R:-64}"
LORA_ALPHA="${LORA_ALPHA:-128}"
LORA_DROPOUT="${LORA_DROPOUT:-0.05}"
LORA_TARGET_MODULES="${LORA_TARGET_MODULES:-q_proj,k_proj,v_proj,o_proj,gate_proj,up_proj,down_proj}"

BATCH_SIZE="${BATCH_SIZE:-8}"
GRAD_ACCUM="${GRAD_ACCUM:-2}"
PRECISION="${PRECISION:-bf16}"
NUM_WORKERS="${NUM_WORKERS:-4}"
SEED="${SEED:-42}"

WARMUP_RATIO="${WARMUP_RATIO:-0.1}"
WEIGHT_DECAY="${WEIGHT_DECAY:-0.001}"
GRAD_CLIP="${GRAD_CLIP:-1.0}"

EVAL_PARALLEL="${EVAL_PARALLEL:-4}"

RUN_TAG="${RUN_TAG:-visa_qwen3vl2b_full_e${EPOCHS}_lr${LR}_bs${BATCH_SIZE}_ga${GRAD_ACCUM}_two_source_triplet_anomalygpt_eval_each_epoch_parallel${EVAL_PARALLEL}}"

source "${SCRIPT_DIR}/_train_and_eval_each_epoch_anomalygpt_parallel_common.sh"
