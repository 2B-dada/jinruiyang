#!/usr/bin/env bash
set -euo pipefail

# Common "train + AnomalyGPT-aligned eval (each epoch) with parallel eval jobs" runner.
#
# This file is intended to be sourced by per-experiment wrapper scripts.

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd -- "${SCRIPT_DIR}/../.." && pwd)"

export PYTHONUNBUFFERED=1
export TOKENIZERS_PARALLELISM=false

# Path defaults (DATA_ROOT / MODEL_PATH / SAM_CKPT / MVTEC_ROOT / VISA_ROOT / DTD_ROOT)
# Edit `train/scripts/env.sh` once to adapt paths on a new machine.
source "${SCRIPT_DIR}/env.sh"

DATASET="${DATASET:-}"
if [[ -z "${DATASET}" ]]; then
  echo "[run] DATASET is required (mvtec|visa)." >&2
  exit 1
fi

TRAIN_PY=""
EVAL_PY=""
DATA_ARG=""
DATA_ROOT_PATH=""

case "${DATASET}" in
  mvtec)
    TRAIN_PY="train/train_mvtec_two_source_triplet.py"
    EVAL_PY="eval/AnomalyGPT_eval_mvtec.py"
    DATA_ARG="--mvtec_root"
    DATA_ROOT_PATH="${MVTEC_ROOT}"
    ;;
  visa)
    TRAIN_PY="train/train_visa_two_source_triplet.py"
    EVAL_PY="eval/AnomalyGPT_eval_visa.py"
    DATA_ARG="--visa_root"
    DATA_ROOT_PATH="${VISA_ROOT}"
    ;;
  *)
    echo "[run] Unsupported DATASET=${DATASET} (expected mvtec|visa)." >&2
    exit 1
    ;;
esac

# ----------------------------
# Common knobs (wrappers override via env vars)
# ----------------------------
CATEGORIES="${CATEGORIES:-}"
K_SHOT="${K_SHOT:-}"
PAIRED="${PAIRED:-1}"
ANOMALY_PROB="${ANOMALY_PROB:-1.0}"

EPOCHS="${EPOCHS:-30}"
LR="${LR:-5e-5}"
SAM_LR="${SAM_LR:-3e-4}"

LORA_R="${LORA_R:-32}"
LORA_ALPHA="${LORA_ALPHA:-64}"
LORA_DROPOUT="${LORA_DROPOUT:-0.05}"
LORA_TARGET_MODULES="${LORA_TARGET_MODULES:-q_proj,k_proj,v_proj,o_proj,gate_proj,up_proj,down_proj}"

BATCH_SIZE="${BATCH_SIZE:-2}"
PRECISION="${PRECISION:-bf16}"
NUM_WORKERS="${NUM_WORKERS:-4}"
SEED="${SEED:-42}"
GRAD_ACCUM="${GRAD_ACCUM:-8}"

WARMUP_RATIO="${WARMUP_RATIO:-0.1}"
WEIGHT_DECAY="${WEIGHT_DECAY:-0.001}"
GRAD_CLIP="${GRAD_CLIP:-1.0}"
GT_MASK_THRESHOLD="${GT_MASK_THRESHOLD:-0.3}"

# --- AnomalyGPT-aligned evaluation settings ---
EVAL_INFERENCE_STRATEGY="${EVAL_INFERENCE_STRATEGY:-teacher_forcing}"
EVAL_SIZE="${EVAL_SIZE:-224}"
EVAL_PROMPT_SOURCE="${EVAL_PROMPT_SOURCE:-anomalygpt_question}"
EVAL_USER_QUESTION="${EVAL_USER_QUESTION:-You are an expert industrial inspector. Please inspect this image strictly and determine whether the object is normal or defective. Always provide a segmentation mask. If the object is normal, the mask should be empty.}"
EVAL_ASSISTANT_STUB="${EVAL_ASSISTANT_STUB:-Segmentation mask: <SEG>.}"
EVAL_LIMIT_PER_CLASS="${EVAL_LIMIT_PER_CLASS:-}" # leave empty for full per-class eval
EVAL_SEED="${EVAL_SEED:-0}"

# Parallel eval controls
EVAL_PARALLEL="${EVAL_PARALLEL:-1}"
EVAL_GPU_LIST="${EVAL_GPU_LIST:-${CUDA_VISIBLE_DEVICES:-}}"

RUN_TAG="${RUN_TAG:-${DATASET}_qwen3vl_full_e${EPOCHS}_lr${LR}_two_source_triplet_anomalygpt_eval_each_epoch_parallel${EVAL_PARALLEL}}"
STAMP="$(date +%Y%m%d_%H%M%S)"
OUT_DIR="${OUT_DIR:-${ROOT_DIR}/outputs/${RUN_TAG}_${STAMP}}"
EVAL_DIR="${OUT_DIR}/eval_anomalygpt"

if [[ -e "${OUT_DIR}" ]]; then
  echo "[run] Refusing to overwrite existing OUT_DIR=${OUT_DIR}" >&2
  exit 1
fi

mkdir -p "${OUT_DIR}" "${EVAL_DIR}"

cd "${ROOT_DIR}"

echo "[run] ROOT_DIR=${ROOT_DIR}"
echo "[run] OUT_DIR=${OUT_DIR}"
echo "[run] DATASET=${DATASET}"
echo "[run] MODEL_PATH=${MODEL_PATH}"
echo "[run] SAM_CKPT=${SAM_CKPT}"
echo "[run] DATA_ROOT_PATH=${DATA_ROOT_PATH}"
echo "[run] DTD_ROOT=${DTD_ROOT}"
echo "[run] CATEGORIES=${CATEGORIES:-<all>} | k_shot=${K_SHOT:-<all>} | paired=${PAIRED} | anomaly_prob=${ANOMALY_PROB}"
echo "[run] epochs=${EPOCHS} | lr=${LR} | sam_lr=${SAM_LR} | gt_mask_threshold=${GT_MASK_THRESHOLD} | lora_r=${LORA_R} | lora_alpha=${LORA_ALPHA} | lora_dropout=${LORA_DROPOUT} | batch_size=${BATCH_SIZE} | grad_accum=${GRAD_ACCUM} | precision=${PRECISION}"
echo "[run] eval: strategy=${EVAL_INFERENCE_STRATEGY} | size=${EVAL_SIZE} | prompt_source=${EVAL_PROMPT_SOURCE} | seed=${EVAL_SEED} | limit_per_class=${EVAL_LIMIT_PER_CLASS:-<none>} | parallel=${EVAL_PARALLEL} | gpu_list=${EVAL_GPU_LIST:-<inherit>}"

# Save a copy of the wrapper script for reproducibility (BASH_SOURCE[1]).
CALLER_SCRIPT="${BASH_SOURCE[1]:-${BASH_SOURCE[0]}}"
cp -f -- "${CALLER_SCRIPT}" "${OUT_DIR}/run_script.sh"

TRAIN_ARGS=(
  --model_path "${MODEL_PATH}"
  --sam_checkpoint "${SAM_CKPT}"
  "${DATA_ARG}" "${DATA_ROOT_PATH}"
  --output_dir "${OUT_DIR}"
  --anomaly_prob "${ANOMALY_PROB}"
  --epochs "${EPOCHS}"
  --batch_size "${BATCH_SIZE}"
  --grad_accum "${GRAD_ACCUM}"
  --lr "${LR}"
  --sam_lr "${SAM_LR}"
  --warmup_ratio "${WARMUP_RATIO}"
  --weight_decay "${WEIGHT_DECAY}"
  --grad_clip "${GRAD_CLIP}"
  --gt_mask_threshold "${GT_MASK_THRESHOLD}"
  --num_workers "${NUM_WORKERS}"
  --precision "${PRECISION}"
  --seed "${SEED}"
  --save_every 1
  --log_every 50
  --dtd_root "${DTD_ROOT}"
  --lora_r "${LORA_R}"
  --lora_alpha "${LORA_ALPHA}"
  --lora_dropout "${LORA_DROPOUT}"
  --lora_target_modules "${LORA_TARGET_MODULES}"
  --train_full_token_embeddings
)

if [[ -n "${CATEGORIES}" ]]; then
  TRAIN_ARGS+=(--categories "${CATEGORIES}")
fi
if [[ -n "${K_SHOT}" ]]; then
  TRAIN_ARGS+=(--k_shot "${K_SHOT}")
fi
if [[ "${PAIRED}" == "1" ]]; then
  TRAIN_ARGS+=(--paired)
fi

echo "[run] Training..."
python "${TRAIN_PY}" "${TRAIN_ARGS[@]}" 2>&1 | tee "${OUT_DIR}/train.stdout.log"

echo "[run] Evaluating every epoch checkpoint (parallel=${EVAL_PARALLEL})..."
SUMMARY_CSV="${EVAL_DIR}/summary.csv"
echo "epoch,mean_i_AUROC,mean_p_AUROC,total_time_sec" > "${SUMMARY_CSV}"

IFS=',' read -r -a _EVAL_GPUS <<< "${EVAL_GPU_LIST}"
if [[ -z "${EVAL_GPU_LIST}" ]]; then
  _EVAL_GPUS=("")
fi

for ((batch_start=1; batch_start<=EPOCHS; batch_start+=EVAL_PARALLEL)); do
  pids=()
  epochs_in_batch=()

  for ((i=0; i<EVAL_PARALLEL && batch_start+i<=EPOCHS; i++)); do
    epoch=$((batch_start+i))
    epochs_in_batch+=("${epoch}")

    EPOCH_DIR="${OUT_DIR}/epoch_${epoch}"
    if [[ ! -d "${EPOCH_DIR}" ]]; then
      echo "[run] Missing checkpoint dir: ${EPOCH_DIR}" >&2
      exit 1
    fi
    if [[ ! -f "${EPOCH_DIR}/text_proj.pt" ]]; then
      echo "[run] Missing: ${EPOCH_DIR}/text_proj.pt" >&2
      exit 1
    fi
    if [[ ! -f "${EPOCH_DIR}/sam_mask_decoder.pt" ]]; then
      echo "[run] Missing: ${EPOCH_DIR}/sam_mask_decoder.pt" >&2
      exit 1
    fi

    EVAL_LOG="${EVAL_DIR}/epoch_${epoch}.log"
    EVAL_JSON="${EVAL_DIR}/epoch_${epoch}.json"
    EVAL_STDOUT="${EVAL_DIR}/epoch_${epoch}.stdout.log"

    EVAL_ARGS=(
      --model_path "${MODEL_PATH}"
      --sam_checkpoint "${SAM_CKPT}"
      "${DATA_ARG}" "${DATA_ROOT_PATH}"
      --lora_path "${EPOCH_DIR}"
      --text_proj "${EPOCH_DIR}/text_proj.pt"
      --sam_mask_decoder "${EPOCH_DIR}/sam_mask_decoder.pt"
      --inference_strategy "${EVAL_INFERENCE_STRATEGY}"
      --eval_size "${EVAL_SIZE}"
      --prompt_source "${EVAL_PROMPT_SOURCE}"
      --user_question "${EVAL_USER_QUESTION}"
      --assistant_stub "${EVAL_ASSISTANT_STUB}"
      --seed "${EVAL_SEED}"
      --output_json "${EVAL_JSON}"
      --log_file "${EVAL_LOG}"
    )

    if [[ -n "${CATEGORIES}" ]]; then
      EVAL_ARGS+=(--categories "${CATEGORIES}")
    fi
    if [[ -n "${EVAL_LIMIT_PER_CLASS}" ]]; then
      EVAL_ARGS+=(--limit_per_class "${EVAL_LIMIT_PER_CLASS}")
    fi

    gpu="${_EVAL_GPUS[i % ${#_EVAL_GPUS[@]}]}"
    if [[ -n "${gpu}" ]]; then
      echo "[run] Launch eval epoch ${epoch}/${EPOCHS} on GPU ${gpu}..."
      CUDA_VISIBLE_DEVICES="${gpu}" python "${EVAL_PY}" "${EVAL_ARGS[@]}" > "${EVAL_STDOUT}" 2>&1 &
    else
      echo "[run] Launch eval epoch ${epoch}/${EPOCHS}..."
      python "${EVAL_PY}" "${EVAL_ARGS[@]}" > "${EVAL_STDOUT}" 2>&1 &
    fi
    pids+=("$!")
  done

  for j in "${!pids[@]}"; do
    pid="${pids[j]}"
    epoch="${epochs_in_batch[j]}"
    if ! wait "${pid}"; then
      echo "[run] Eval failed for epoch ${epoch}. Check: ${EVAL_DIR}/epoch_${epoch}.stdout.log" >&2
      exit 1
    fi
  done

  for epoch in "${epochs_in_batch[@]}"; do
    EVAL_JSON="${EVAL_DIR}/epoch_${epoch}.json"
    if [[ ! -f "${EVAL_JSON}" ]]; then
      echo "[run] Missing eval json: ${EVAL_JSON}" >&2
      exit 1
    fi
    python - <<PY >> "${SUMMARY_CSV}"
import json
path = r"${EVAL_JSON}"
with open(path, "r", encoding="utf-8") as f:
    d = json.load(f)
epoch = int(${epoch})
i_auc = d.get("mean_i_AUROC")
p_auc = d.get("mean_p_AUROC")
t = d.get("total_time_sec")
print(f"{epoch},{i_auc},{p_auc},{t}")
PY
  done
done

echo "[run] Done."
echo "  - Train logs: ${OUT_DIR}/train.log , ${OUT_DIR}/train.stdout.log"
echo "  - Eval logs/json: ${EVAL_DIR}/"
echo "  - Summary: ${SUMMARY_CSV}"
