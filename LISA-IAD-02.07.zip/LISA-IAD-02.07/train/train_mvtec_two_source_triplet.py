import argparse
import json
import logging
import math
import os
import random
import sys
import time

ROOT_DIR = os.path.dirname(os.path.dirname(__file__))
if ROOT_DIR not in sys.path:
    sys.path.append(ROOT_DIR)

import numpy as np
import torch
from peft import LoraConfig, get_peft_model
from torch.utils.data import DataLoader
from tqdm import tqdm
from transformers import AutoProcessor, Qwen3VLForConditionalGeneration, get_cosine_schedule_with_warmup

from data import Qwen3VLCollator
from data.paired_collator import PairedQwen3VLCollator
from data.mvtec_dataset_two_source import MVtecIADDatasetTwoSource
from data.mvtec_triplet_dataset_two_source import MVtecIADTripletDatasetTwoSource
from model import LISAQwenForSegmentation


def parse_args():
    parser = argparse.ArgumentParser(description="Train LISA-IAD on MVTec-AD (normal + same-class + DTD synthetic).")
    parser.add_argument("--model_path", type=str, required=True)
    parser.add_argument("--sam_checkpoint", type=str, required=True)
    parser.add_argument("--mvtec_root", type=str, required=True)
    parser.add_argument("--output_dir", type=str, required=True)
    parser.add_argument(
        "--categories",
        type=str,
        default=None,
        help="Comma-separated MVTec categories (default: all).",
    )
    parser.add_argument("--k_shot", type=int, default=None)
    parser.add_argument("--anomaly_prob", type=float, default=0.5)
    parser.add_argument(
        "--assistant_mask_only",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Use a fixed assistant stub containing <SEG> only (aligns with teacher-forcing inference).",
    )
    parser.add_argument(
        "--paired",
        action="store_true",
        default=False,
        help="If set, each dataset item yields 3 samples: normal + same-class synthetic + DTD synthetic.",
    )
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch_size", type=int, default=2)
    parser.add_argument("--grad_accum", type=int, default=8)
    parser.add_argument("--lr", type=float, default=5e-5)
    parser.add_argument(
        "--sam_lr",
        type=float,
        default=3e-4,
        help="Learning rate for SAM mask decoder (default: lr).",
    )
    parser.add_argument("--weight_decay", type=float, default=0.001)
    parser.add_argument("--grad_clip", type=float, default=1.0)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--precision", type=str, default="bf16", choices=["fp32", "fp16", "bf16"])
    parser.add_argument("--lora_r", type=int, default=32)
    parser.add_argument("--lora_alpha", type=int, default=64)
    parser.add_argument("--lora_dropout", type=float, default=0.05)
    parser.add_argument(
        "--lora_target_modules",
        type=str,
        default="q_proj,k_proj,v_proj,o_proj,gate_proj,up_proj,down_proj",
        help="Comma-separated substrings to match Linear layer names for LoRA (AnomalyGPT uses q/k/v/o proj).",
    )
    parser.add_argument(
        "--train_mask_decoder",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Train SAM mask decoder (recommended; aligns with LISA).",
    )
    parser.add_argument(
        "--warmup_ratio",
        type=float,
        default=0.1,
        help="Warmup steps as a ratio of total optimizer steps (default: 0.1).",
    )
    parser.add_argument(
        "--warmup_steps",
        type=int,
        default=None,
        help="Override warmup steps (default: computed from warmup_ratio).",
    )
    parser.add_argument(
        "--gt_mask_threshold",
        type=float,
        default=0.3,
        help="Binarize GT masks for mask loss via gt>thr (default: 0.3; AnomalyGPT uses 0.3). Set <0 to disable.",
    )
    parser.add_argument(
        "--mask_loss_on_normals",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Compute mask loss on normal samples as empty-mask supervision (soft-measurement training).",
    )
    parser.add_argument(
        "--train_full_token_embeddings",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Train full token embeddings/lm_head (LISA default). Use --no-train_full_token_embeddings to only update <SEG> row.",
    )
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--save_every", type=int, default=1)
    parser.add_argument("--log_every", type=int, default=10)

    # DTD path (used by both MVtecIADDatasetTwoSource and MVtecIADTripletDatasetTwoSource).
    parser.add_argument(
        "--dtd_root",
        type=str,
        required=True,
        help="DTD images root directory.",
    )
    return parser.parse_args()


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def seed_worker(worker_id: int):
    worker_info = torch.utils.data.get_worker_info()
    if worker_info is None:
        return
    seed = worker_info.seed
    random.seed(seed)
    np.random.seed(seed % (2**32 - 1))
    dataset = worker_info.dataset
    if hasattr(dataset, "rng"):
        dataset.rng = random.Random(seed)


def find_linear_layers(model, target_names):
    cls = torch.nn.Linear
    matches = []
    for name, module in model.named_modules():
        if isinstance(module, cls) and any(t in name for t in target_names):
            matches.append(name)
    return sorted(set(matches))


def setup_logger(output_dir: str) -> logging.Logger:
    logger = logging.getLogger("lisa_iad_train_mvtec_two_source_triplet")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    fmt = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")

    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    logger.addHandler(sh)

    fh = logging.FileHandler(os.path.join(output_dir, "train.log"), encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    logger.propagate = False
    return logger


def count_params(model):
    total = 0
    trainable = 0
    for p in model.parameters():
        n = p.numel()
        total += n
        if p.requires_grad:
            trainable += n
    return total, trainable


def main():
    args = parse_args()
    set_seed(args.seed)
    os.makedirs(args.output_dir, exist_ok=True)
    logger = setup_logger(args.output_dir)
    logger.info("Args: %s", json.dumps(vars(args), ensure_ascii=False, indent=2))

    categories = None
    if args.categories:
        categories = [c.strip() for c in args.categories.split(",") if c.strip()]

    processor = AutoProcessor.from_pretrained(args.model_path)
    tokenizer = processor.tokenizer

    num_added = tokenizer.add_tokens(["<SEG>"])
    seg_token_idx = tokenizer("<SEG>", add_special_tokens=False).input_ids[0]

    qwen = Qwen3VLForConditionalGeneration.from_pretrained(args.model_path, dtype="auto")
    qwen.config.use_cache = False
    if num_added > 0:
        qwen.resize_token_embeddings(len(tokenizer))

    for param in qwen.parameters():
        param.requires_grad = False

    lora_targets = args.lora_target_modules.split(",")
    lora_modules = find_linear_layers(qwen, lora_targets)
    if len(lora_modules) == 0:
        raise ValueError("No LoRA target modules found. Check --lora_target_modules.")

    lora_config = LoraConfig(
        r=args.lora_r,
        lora_alpha=args.lora_alpha,
        target_modules=lora_modules,
        lora_dropout=args.lora_dropout,
        modules_to_save=["embed_tokens", "lm_head"],
        ensure_weight_tying=True,
        bias="none",
        task_type="CAUSAL_LM",
    )
    qwen = get_peft_model(qwen, lora_config)

    embed_module = qwen.get_input_embeddings()
    if embed_module is None or not hasattr(embed_module, "weight"):
        raise ValueError("Failed to locate input embeddings via get_input_embeddings().")
    embed_weight = embed_module.weight

    lm_head_weight = None
    try:
        out_module = qwen.get_output_embeddings()
    except Exception:
        out_module = getattr(qwen, "lm_head", None)
    if out_module is not None and hasattr(out_module, "weight"):
        lm_head_weight = out_module.weight
    embed_weight.requires_grad = True
    if lm_head_weight is not None:
        lm_head_weight.requires_grad = True

    if not args.train_full_token_embeddings:

        def _keep_only_seg_row(grad: torch.Tensor | None):
            if grad is None:
                return grad
            masked = torch.zeros_like(grad)
            masked[seg_token_idx] = grad[seg_token_idx]
            return masked

        embed_weight.register_hook(_keep_only_seg_row)
        if lm_head_weight is not None and lm_head_weight is not embed_weight:
            lm_head_weight.register_hook(_keep_only_seg_row)
        logger.info("Token tuning: only <SEG> row is trainable (idx=%d).", seg_token_idx)
    else:
        logger.info("Token tuning: full token embeddings/lm_head are trainable.")

    gt_mask_threshold = None if args.gt_mask_threshold < 0 else float(args.gt_mask_threshold)

    model = LISAQwenForSegmentation(
        qwen_model=qwen,
        sam_checkpoint=args.sam_checkpoint,
        seg_token_idx=seg_token_idx,
        train_mask_decoder=args.train_mask_decoder,
        gt_mask_threshold=gt_mask_threshold,
        mask_loss_on_normals=bool(args.mask_loss_on_normals),
    )

    model.text_proj.train()
    for param in model.text_proj.parameters():
        param.requires_grad = True

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)

    if args.paired:
        dataset = MVtecIADTripletDatasetTwoSource(
            root_dir=args.mvtec_root,
            split="train",
            categories=categories,
            k_shot=args.k_shot,
            anomaly_prob=args.anomaly_prob,
            mask_threshold=gt_mask_threshold,
            return_assistant=True,
            assistant_mask_only=bool(args.assistant_mask_only),
            seed=args.seed,
            dtd_root=str(args.dtd_root),
        )
        collator = PairedQwen3VLCollator(processor, training=True)
        batch_factor = 3
    else:
        dataset = MVtecIADDatasetTwoSource(
            root_dir=args.mvtec_root,
            split="train",
            categories=categories,
            k_shot=args.k_shot,
            anomaly_prob=args.anomaly_prob,
            mask_threshold=gt_mask_threshold,
            return_assistant=True,
            assistant_mask_only=bool(args.assistant_mask_only),
            seed=args.seed,
            dtd_root=str(args.dtd_root),
        )
        collator = Qwen3VLCollator(processor, training=True)
        batch_factor = 1

    loader = DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        collate_fn=collator,
        worker_init_fn=seed_worker,
        persistent_workers=args.num_workers > 0,
    )

    sam_lr = args.sam_lr if args.sam_lr is not None else args.lr

    trainable = [p for p in model.parameters() if p.requires_grad]
    sam_param_ids = {id(p) for p in model.sam.mask_decoder.parameters() if p.requires_grad}
    embed_param_ids = {id(embed_weight)}
    if lm_head_weight is not None:
        embed_param_ids.add(id(lm_head_weight))

    other_params = []
    sam_params = []
    embed_params = []
    seen = set()
    for p in trainable:
        pid = id(p)
        if pid in seen:
            continue
        seen.add(pid)
        if pid in sam_param_ids:
            sam_params.append(p)
        elif pid in embed_param_ids:
            embed_params.append(p)
        else:
            other_params.append(p)

    param_groups = []
    if other_params:
        param_groups.append({"params": other_params, "lr": args.lr, "weight_decay": args.weight_decay})
    if embed_params:
        param_groups.append({"params": embed_params, "lr": args.lr, "weight_decay": 0.0})
    if sam_params:
        param_groups.append({"params": sam_params, "lr": sam_lr, "weight_decay": args.weight_decay})

    optimizer = torch.optim.AdamW(param_groups, betas=(0.9, 0.95), eps=1e-8)

    scaler = None
    if args.precision == "fp16":
        scaler = torch.cuda.amp.GradScaler()

    optim_steps_per_epoch = int(math.ceil(len(loader) / max(1, args.grad_accum)))
    total_optim_steps = optim_steps_per_epoch * args.epochs
    warmup_steps = (
        int(args.warmup_steps)
        if args.warmup_steps is not None
        else int(total_optim_steps * float(args.warmup_ratio))
    )
    warmup_steps = max(0, min(warmup_steps, total_optim_steps))
    if warmup_steps == 0 and args.warmup_ratio > 0 and total_optim_steps > 0:
        warmup_steps = 1
    scheduler = get_cosine_schedule_with_warmup(
        optimizer=optimizer,
        num_warmup_steps=warmup_steps,
        num_training_steps=total_optim_steps,
    )

    total_params, trainable_params = count_params(model)
    logger.info("Device: %s", device)
    logger.info("Dataset size: %d | batches/epoch: %d", len(dataset), len(loader))
    logger.info("Params: total=%d | trainable=%d", total_params, trainable_params)
    logger.info("Triplet training (paired=%s) | batch_factor=%d", args.paired, batch_factor)
    logger.info(
        "Effective batch size: %d (batch_size=%d, grad_accum=%d, factor=%d)",
        args.batch_size * args.grad_accum * batch_factor,
        args.batch_size,
        args.grad_accum,
        batch_factor,
    )
    logger.info(
        "LRs: base=%.2e | sam_mask_decoder=%.2e | token_full=%s",
        args.lr,
        sam_lr if sam_params else 0.0,
        args.train_full_token_embeddings,
    )
    logger.info(
        "Scheduler: linear warmup + cosine decay | warmup_steps=%d | total_optim_steps=%d",
        warmup_steps,
        total_optim_steps,
    )
    logger.info(
        "Trainable groups: other=%d | token=%d | sam_decoder=%d",
        sum(p.numel() for p in other_params),
        sum(p.numel() for p in embed_params),
        sum(p.numel() for p in sam_params),
    )
    logger.info("GT mask threshold for loss: %s", gt_mask_threshold)
    logger.info("DTD root: %s", str(args.dtd_root))

    train_start = time.time()
    history = []

    for epoch in range(args.epochs):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        epoch_start = time.time()
        running = {
            "loss": 0.0,
            "ce_loss": 0.0,
            "mask_loss": 0.0,
            "mask_focal_loss": 0.0,
            "mask_dice_loss": 0.0,
            "anom_ratio": 0.0,
        }
        n_steps = 0
        num_batches = len(loader)
        optim_steps = 0

        pbar = tqdm(
            enumerate(loader, start=1),
            total=len(loader),
            desc=f"Epoch {epoch+1}/{args.epochs}",
            dynamic_ncols=True,
        )
        for step, batch in pbar:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)
            pixel_values = batch["pixel_values"].to(device) if batch["pixel_values"] is not None else None
            image_grid_thw = batch["image_grid_thw"].to(device) if batch["image_grid_thw"] is not None else None
            sam_images = batch["sam_images"].to(device)
            has_mask = batch["has_mask"].to(device)

            if args.precision == "bf16":
                autocast_dtype = torch.bfloat16
            elif args.precision == "fp16":
                autocast_dtype = torch.float16
            else:
                autocast_dtype = torch.float32

            with torch.autocast(
                device_type=device.type,
                dtype=autocast_dtype,
                enabled=args.precision != "fp32",
            ):
                outputs = model(
                    input_ids=input_ids,
                    attention_mask=attention_mask,
                    pixel_values=pixel_values,
                    image_grid_thw=image_grid_thw,
                    sam_images=sam_images,
                    sam_resize=batch["sam_resize"],
                    sam_original_size=batch["sam_original_size"],
                    labels=labels,
                    gt_masks=batch["gt_masks"],
                    has_mask=has_mask,
                )
                total_loss = outputs["loss"]
                loss = total_loss / args.grad_accum

            if scaler is not None:
                scaler.scale(loss).backward()
            else:
                loss.backward()

            did_step = False
            if (step % args.grad_accum == 0) or (step == num_batches):
                if args.grad_clip is not None and float(args.grad_clip) > 0:
                    if scaler is not None:
                        scaler.unscale_(optimizer)
                    torch.nn.utils.clip_grad_norm_(trainable, float(args.grad_clip))
                if scaler is not None:
                    scaler.step(optimizer)
                    scaler.update()
                else:
                    optimizer.step()
                scheduler.step()
                optimizer.zero_grad(set_to_none=True)
                optim_steps += 1
                did_step = True

            with torch.no_grad():
                n_steps += 1
                loss_val = float(total_loss.detach().float().item())
                ce_val = (
                    float(outputs["ce_loss"].detach().float().item())
                    if outputs.get("ce_loss") is not None
                    else 0.0
                )
                mask_val = float(outputs["mask_loss"].detach().float().item())
                mask_focal_val = float(outputs["mask_focal_loss"].detach().float().item())
                mask_dice_val = float(outputs["mask_dice_loss"].detach().float().item())
                anom_ratio = float(has_mask.float().mean().item())
                lr = optimizer.param_groups[0]["lr"]

                running["loss"] += loss_val
                running["ce_loss"] += ce_val
                running["mask_loss"] += mask_val
                running["mask_focal_loss"] += mask_focal_val
                running["mask_dice_loss"] += mask_dice_val
                running["anom_ratio"] += anom_ratio

                if step % args.log_every == 0 or step == 1:
                    pbar.set_postfix(
                        loss=f"{loss_val:.3f}",
                        ce=f"{ce_val:.3f}",
                        mask=f"{mask_val:.3f}",
                        anom=f"{anom_ratio:.2f}",
                        lr=f"{lr:.2e}",
                    )
                    logger.info(
                        "Epoch %d | step %d/%d | opt_step %d%s | loss=%.4f ce=%.4f mask=%.4f anom=%.3f lr=%.2e",
                        epoch + 1,
                        step,
                        num_batches,
                        optim_steps,
                        "*" if did_step else "",
                        loss_val,
                        ce_val,
                        mask_val,
                        anom_ratio,
                        lr,
                    )

        if (epoch + 1) % args.save_every == 0:
            save_path = os.path.join(args.output_dir, f"epoch_{epoch+1}")
            os.makedirs(save_path, exist_ok=True)
            model.qwen.save_pretrained(save_path)
            torch.save(model.text_proj.state_dict(), os.path.join(save_path, "text_proj.pt"))
            torch.save(model.sam.mask_decoder.state_dict(), os.path.join(save_path, "sam_mask_decoder.pt"))

        epoch_time = time.time() - epoch_start
        avg = {k: (v / max(1, n_steps)) for k, v in running.items()}
        max_mem = None
        if device.type == "cuda":
            max_mem = torch.cuda.max_memory_allocated() / (1024**3)
            torch.cuda.reset_peak_memory_stats()

        summary = {
            "epoch": epoch + 1,
            "time_sec": epoch_time,
            "avg_loss": avg["loss"],
            "avg_ce_loss": avg["ce_loss"],
            "avg_mask_loss": avg["mask_loss"],
            "avg_mask_focal": avg["mask_focal_loss"],
            "avg_mask_dice": avg["mask_dice_loss"],
            "avg_anom_ratio": avg["anom_ratio"],
            "max_cuda_mem_gb": max_mem,
        }
        history.append(summary)
        logger.info("Epoch summary: %s", json.dumps(summary, ensure_ascii=False))

    total_time = time.time() - train_start
    best_epoch = min(history, key=lambda x: x["avg_loss"])["epoch"] if history else None
    final_summary = {
        "epochs": args.epochs,
        "total_time_sec": total_time,
        "best_epoch_by_loss": best_epoch,
        "history": history,
    }
    logger.info("Training finished: %s", json.dumps(final_summary, ensure_ascii=False, indent=2))
    with open(os.path.join(args.output_dir, "train_summary.json"), "w", encoding="utf-8") as f:
        json.dump(final_summary, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
